<?php

return [
'dashboard' 	=> 'Dashboard',
'category' 		=> 'Category',

];