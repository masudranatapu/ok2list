<?php

return [
    'promotion_sub_title'      =>      'Promotion List',
    'promotion_view_title'     =>      'Promotion View',
    'promotion_title'          =>      'Promotion',
    'package_create_btn'       =>      'Add Package',
    'name'                     =>      'Promotion Name',
    'price'                    =>      'Promotion Price',
    'duration'                 =>      'Duration',
    'action'                   =>      'Action',
    'sl'                       =>      'SL',
    'add_promotion'            =>      'Add Promotion',
    'dashboard'                =>      'Dashboard',
    'edit_promotion'           =>      'Edit Promotion',
 ];
