<?php

return [
    'about_title'      =>     'About Us',
 ];
