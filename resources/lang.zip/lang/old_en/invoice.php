<?php

return [
    'list_page_title' => 'Invoice',
    'list_page_sub_title' => 'Invoice',
    'breadcrumb_title' => 'Dashboard',
    'breadcrumb_sub_title' => 'Invoice',
    'create_btn' => 'New Invoice',
        
    'new_page_title' => 'Invoice | New',    
    
    'edit_page_title' => 'Invoice | Update',
    'edit_page_sub_title' => 'Invoice',
    'edit_page_breadcrumb_title_1' => 'Dashboard',
    'edit_page_breadcrumb_title_2' => 'Invoice',
    'edit_page_breadcrumb_title_active' => 'Update Invoice'
];
