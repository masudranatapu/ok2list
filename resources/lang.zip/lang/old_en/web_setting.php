<?php

return [
    'terms_condition_title'      =>     'Terms & Condition',
    'privacy_policy_title'       =>     'Privacy & Policy',
    'quick_rules_title'          =>     'Quick Rules',
    'faq_title'                  =>     'Faq',
    'mail_config_title'          =>     'Mail Configuration',
    'footer_title'               =>     'Footer',
    'copy_right_title'           =>     'Copyright',
    'howto_sell_title'           =>     'How to Sell Fast',
    'why_membership_title'       =>     'Why Membership',
    'client_query_title'         =>     'Client Query',
    'query_view_title'           =>     'View Query',
    'query_reply_title'          =>     'Reply Query',
    'faq_create'                 =>     'Create Faq',
    'faq_edit'                   =>     'Edit Faq',
    'faq_view'                   =>     'View Faq',
 ];
