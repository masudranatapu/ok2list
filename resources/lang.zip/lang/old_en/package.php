<?php

return [
    'package_menu'             =>      'Package List',
    'list_page_title'          =>      'Package',
    'list_page_sub_title'      =>      'Package',
    'package_create_btn'       =>      'Add Package',
    'name'                     =>      'Package Name',
    'price'                    =>      'Package Price',
    'action'                   =>      'Action',
    'sl'                       =>      'SL',
    'editpackage'              =>      'Edit Package',
    'packageview'              =>      'View Package',
 ];
