<?php

return [
    'list_page_title' => 'Invoice Details',
    'list_page_sub_title' => 'Invoice Details',
    'breadcrumb_title' => 'Dashboard',
    'breadcrumb_sub_title' => 'Invoice Details',
    'create_btn' => 'New Invoice Details',
        
    'new_page_title' => 'Invoice Details | New',    
    
    'edit_page_title' => 'Invoice Details | Update',
    'edit_page_sub_title' => 'Invoice Details',
    'edit_page_breadcrumb_title_1' => 'Dashboard',
    'edit_page_breadcrumb_title_2' => 'Invoice Details',
    'edit_page_breadcrumb_title_active' => 'Update Invoice Details',
];
