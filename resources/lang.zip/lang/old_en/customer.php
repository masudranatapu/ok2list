<?php

return [
    'customer_info'             =>      'Customer Info',
    'customer_address'          =>      'Customer Address',
    'add_new_customer'          =>      'Add New Customer',
    'update_customer'          =>      'Update Customer',
    'breadcrumb_title'          =>      'Dashboard',
    'breadcrumb_sub_title'      =>      'Customer',
    'customer_create_btn'       =>      'Add Customer',
    'customer_address_btn'       =>      'Add Address',
    'list_page_title'           =>      'Customer',
    'list_page_sub_title'       =>      'Customer',
    'order_info'                =>      'Order Info',
    'customer_view'             =>      'Customer View',
 ];
