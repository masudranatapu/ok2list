<?php $__env->startSection('content'); ?>

<?php
$category  = $data['category'] ?? null;
$subcategory  = $data['subcategory'] ?? null;

?>

<?php $__env->startPush('custom_css'); ?>
<style type="text/css">
	 html {
	  scroll-behavior: smooth;
	}
</style>
<?php $__env->stopPush(); ?>
<!-- post-page -->
<section id="main" class="clearfix ad-post-page">
	<div class="container">

		<div class="breadcrumb-section">
			<!-- breadcrumb -->
			<ol class="breadcrumb">
				<li><a href="index.html">Home</a></li>
				<li>Ad Post</li>
			</ol><!-- breadcrumb -->
		</div><!-- banner -->
		<div id="ad-post">
			<div class="row category-tab">
				<div class="col-lg-4 col-md-6">
					<div class="section cat-option select-category post-option">
						<h4>Select a Category</h4>
						<ul role="tablist" class="nav nav-tabs">
							<?php if(($category) && $category->count() > 0 ): ?>
								<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<li class="<?php echo e(request()->get('type') == $row->url_slug  ? 'link-active' : ''); ?>" ><a onclick="scrollToTop()" href="#cat_<?php echo e($row->pk_no); ?>" aria-controls="cat_<?php echo e($row->pk_no); ?>" role="tab" data-toggle="tab" title="<?php echo e($row->name); ?>" class="<?php echo e(request()->get('type') == $row->url_slug  ? 'active' : ''); ?>" aria-selected="<?php echo e(request()->get('type') == $row->url_slug  ? 'true' : ''); ?>">
										<span class="select">
											<img src="<?php echo e($row->icon_src); ?>" alt="<?php echo e($row->name); ?>" class="img-responsive" style="width: 42px;">
										</span>
										<?php echo e($row->name); ?>

									</a></li>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>


							</ul>
						</div>
					</div>

					<!-- Tab panes -->
					<div class="col-lg-4 col-md-6">
						<div class="section tab-content subcategory post-option" id="subcat">
							<h4>Select a subcategory</h4>
							<?php if(($category) && $category->count() > 0 ): ?>
								<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<div role="tabpanel " class="tab-pane <?php echo e(request()->get('type') == $row->url_slug  ? 'active' : ''); ?>" id="cat_<?php echo e($row->pk_no); ?>">
										<ul>
											<?php if(($subcategory) && $subcategory->count() > 0 ): ?>
											<?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skey => $srow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($row->pk_no == $srow->parent_id ): ?>
													<?php
													$type = null;

													if($row->url_slug == 'property'){
														$type = 'property';

													}elseif($row->url_slug == 'jobs'){

													$type = $row->url_slug;

													}else{
														$type = $row->url_slug ?? request()->type ;
													}
												?>

												<li><a href="<?php echo e(route('ad-post',[$srow->url_slug,'type' => $type, 'category' => $srow->pk_no])); ?>"><?php echo e($srow->name); ?>  </a></li>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</ul>
									</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>

						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="section next-stap post-option">
							<h2>Post an Ad in just <span>30 seconds</span></h2>
							<p>Please DO NOT post multiple ads for the same items or service. All duplicate, spam and wrongly categorized ads will be deleted.</p>
						</div>
					</div><!-- next-stap -->
				</div>
			</div>
		</div><!-- container -->
	</section><!-- post-page -->

	<?php $__env->stopSection(); ?>

	<?php $__env->startPush('custom_js'); ?>
	 <script>

        if ($(window).width() >= 768) {
        	function scrollToTop() {
              $(window).scrollTop(0);
           }
        }else if($(window).width() <= 767){
           function scrollToTop() {
		        $('html, body').animate({
			        scrollTop: $("#subcat").offset().top
			    }, 1000);
           }
        }

    </script>
	<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/ad_post/ad_post_category_selection.blade.php ENDPATH**/ ?>