<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light navbar-border navbar-shadow">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block"><?php echo app('translator')->get('footer.copyright'); ?> <a class="text-bold-800 grey darken-2" href="https://webdevs4u.com/" target="_blank"><?php echo app('translator')->get('footer.organization'); ?></a></span><span class="float-md-right d-none d-lg-block">We<i class="ft-heart pink"></i> to Code <a class="text-bold-800 grey darken-2" href="https://www.webdevs4u.com" target="_blank">Webdevs</a><span id="scroll-top"></span></span></p>
</footer>
<!-- END: Footer-->
<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>