<?php $__env->startPush('custom_css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/forms/validation/form-validation.css')); ?>">
    <link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
    <style type="text/css">
        .user-account input {margin-bottom: 0px !important;}
    </style>
<?php $__env->stopPush(); ?>
    <?php
        $tabindex = 1;
    ?>
<?php $__env->startSection('content'); ?>
    <section id="main" class="clearfix user-page">
        <div class="container">
            <div class="login_page">
                <div class="login_wrapper">
                    <div class="row">
                        <div class="col-lg-7">
                            <div class="login_content">
                                <div class="login_title">
                                    <h3><?php echo app('translator')->get('web.sign_in_to_your_account'); ?></h3>
                                </div>
                                <div class="login_role">
                                    <div class="media position-relative mb-5">
                                        <div class="icon">
                                            <img src="<?php echo e(asset('assets/images/icon/chat.png')); ?>" alt="">
                                        </div>
                                        <div class="login_role_article">
                                            <h3><?php echo app('translator')->get('web.chat_messaging'); ?></h3>
                                            <span><?php echo app('translator')->get('web.access_you_chat'); ?></span>
                                        </div>
                                    </div>
                                    <div class="media position-relative mb-5">
                                    <div class="icon">
                                            <img src="<?php echo e(asset('assets/images/icon/dashboard.png')); ?>" alt="">
                                        </div>
                                        <div class="login_role_article">
                                            <h3><?php echo app('translator')->get('web.user_dashboard'); ?></h3>
                                            <span><?php echo app('translator')->get('web.maintain_a_wish'); ?></span>
                                        </div>
                                    </div>
                                    <div class="media position-relative mb-5">
                                        <div class="icon">
                                            <img src="<?php echo e(asset('assets/images/icon/history.png')); ?>" alt="">
                                        </div>
                                        <div class="login_role_article">
                                            <h3><?php echo app('translator')->get('web.track_history'); ?></h3>
                                            <span><?php echo app('translator')->get('web.track_the_status'); ?></span>
                                        </div>
                                    </div>
                                    <div class="media position-relative mb-5">
                                        <div class="icon">
                                            <img src="<?php echo e(asset('assets/images/icon/target.png')); ?>" alt="">
                                        </div>
                                        <div class="login_role_article">
                                            <h3><?php echo app('translator')->get('web.features_listing'); ?></h3>
                                            <span><?php echo app('translator')->get('web.features_listing_get'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="login_form">
                                <div class="social_login">
                                    <p><?php echo app('translator')->get('web.iread'); ?><a href="<?php echo e(route('terms-conditions')); ?>"><?php echo app('translator')->get('web.t_conditions'); ?></a> and <a href="<?php echo e(route('privacy-policy')); ?>"><?php echo app('translator')->get('web.privacy_policy'); ?></a> <?php echo app('translator')->get('web.before_proceed'); ?></p>    
                                    <div class="social_login_btn">
                                        <div class="row">
                                            <div class="col-6">
                                                <a href="<?php echo e(url('login/facebook')); ?>" class="facebook">
                                                    <i class="fa fa-facebook"></i>
                                                    <span>Facebook</span>
                                                </a>
                                            </div>
                                            <div class="col-6">
                                                <a href="<?php echo e(url('login/google')); ?>" class="google">
                                                    <i class="fa fa-google"></i>
                                                    <span>Google</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="divider">
                                    <p>OR</p>
                                </div>
                                <?php echo Form::open([ 'route' => 'login', 'method' => 'post', 'class' => 'form-horizontal', 'files' => true , 'novalidate']); ?>

                                    <input type="hidden" value="<?php echo e(request()->get('referer')); ?>" name="referer" />
                                    <input type="hidden" value="<?php echo e(request()->get('pakid')); ?>" name="pakid" />
                                    <div class="form-group <?php echo $errors->has('email') ? 'error' : ''; ?>">
                                        <label class="label-title"><?php echo app('translator')->get('web.email'); ?><span class="required">*</span></label>
                                        <div class="controls">
                                            <?php echo Form::text('email', null, [ 'class' => 'form-control', 'data-validation-required-message' => 'This field is required', 'placeholder' => 'Email', 'tabindex' => $tabindex++]); ?>

                                            <?php echo $errors->first('email', '<label class="help-block text-danger">:message</label>'); ?>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="label-title"><?php echo app('translator')->get('web.password'); ?><span class="required">*</span></label>
                                        <div class="controls">
                                            <?php echo Form::password('password', [ 'class' => 'form-control mb-1', 'minlength' => '6', 'data-validation-required-message' => 'This field is required', 'data-validation-minlength-message' => 'Minimum 6 characters', 'placeholder' => 'Enter  password', 'tabindex' => $tabindex++, 'autocomplete' => 'off']); ?>

                                            <?php echo $errors->first('password', '<label class="help-block text-danger">:message</label>'); ?>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="user-option">
                                                <div class="checkbox pull-left">
                                                    <label for="logged"><input type="checkbox" name="logged" id="logged"> <?php echo app('translator')->get('web.remember'); ?></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="forgot_pass float-right">
                                                <a href="<?php echo e(route('password.request')); ?>"><?php echo app('translator')->get('web.forget_password'); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="login_btn">
                                        <button type="submit" class="btn w-100"><?php echo app('translator')->get('web.login'); ?></button>
                                    </div>
                                    <div class="sign_up text-center">
                                        <p><a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('web.sign_up'); ?></a></p>
                                    </div>
                                    <?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- row -->
        </div><!-- container -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_js'); ?>
    <script src="<?php echo e(asset('/assets/js/forms/validation/jqBootstrapValidation.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/forms/validation/form-validation.js')); ?>"></script>
    <script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
    <?php echo Toastr::message(); ?>

    <script type="text/javascript">
            jQuery(document).ready(function ($) {
                let n1 = parseInt($('#n1').val());
                let n2 = parseInt($('#n2').val());
                let captcha = $('#captcha_input');

                captcha.keyup(function () {
                    captcha.next().next().hide();
                })

                $('#captcha_input').keyup(function (e) {
                    e.preventDefault();

                    if (n1 + n2 !== parseInt(captcha.val())) {
                        captcha.next().next().show();
                    }
                });

            })

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/auth/login.blade.php ENDPATH**/ ?>