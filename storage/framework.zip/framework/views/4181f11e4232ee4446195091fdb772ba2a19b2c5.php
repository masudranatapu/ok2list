<?php $__env->startPush('custom_css'); ?>
<style type="text/css">
.contact-us h2.title {
font-size: 20px;
}
h2.h3.title a {
color: #000000;
}
.sitemap ul li a{
text-decoration: none;
outline: none;
color: #3a3a3c;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section id="main" class="clearfix ad-details-page sitemap">
   <div class="container">
      <div class="breadcrumb-section">
         <!-- breadcrumb -->
         <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><?php echo app('translator')->get('web.sitemap'); ?></li>
            </ol><!-- breadcrumb -->
            <!-- <h2 class="title">Privacy Policy</h2> -->
            </div>

            <?php if(isset($data['site_map_page2']) && ($data['site_map_page2']) != null ): ?>
            <div class="container">
                 <div class="ads_banner text-center mb-4">
                     <a href="<?php echo e($data['site_map_page2']->link); ?>" target="_blank" title="<?php echo e($data['site_map_page2']->name); ?>"><img src="<?php echo e(fileExit($data['site_map_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['site_map_page2']->name); ?>" style="height: 96px;"></a>
                 </div>
             </div>
             <?php endif; ?>

            <div class="adpost-details privacy-policy">
               <div class="row"></div>
                     <div class="section">
                        <?php if($data['data']['category'] && count($data['data']['category']) > 0 ): ?>
                        <?php $__currentLoopData = $data['data']['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sitemap_wrapper">
                           <h3><a target="_blank" href="<?php echo e(route('ads.list', ['area' => 'srilanka', 'category' => $cat->url_slug])); ?>"><?php echo e($cat->name); ?></a></h3>
                           <div class="row">
                              <?php if($data['data']['subcategory'] && count($data['data']['subcategory']) > 0 ): ?>
                              <?php $__currentLoopData = $data['data']['subcategory']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ckey => $scat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($cat->pk_no == $scat->parent_id ): ?>
                              <div class="col-md-4">
                                 <ul class="site_item_list">

                                    <li>
                                       <a target="_blank" href="<?php echo e(route('ads.list', ['area' => 'srilanka', 'category' => $scat->url_slug])); ?>"><i class="fa fa-book"></i> <?php echo e($scat->name); ?></a>
                                    </li>

                                 </ul>
                              </div>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                           </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            <?php if(isset($data['site_map_page2']) && ($data['site_map_page2']) != null ): ?>
            <div class="container">
                 <div class="ads_banner text-center mb-4">
                     <a href="<?php echo e($data['site_map_page2']->link); ?>" target="_blank" title="<?php echo e($data['site_map_page2']->name); ?>"><img src="<?php echo e(fileExit($data['site_map_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['site_map_page2']->name); ?>" style="height: 96px;"></a>
                 </div>
             </div>
             <?php endif; ?>


        </div><!-- container -->
        </section><!-- main -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('custom_js'); ?>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/common/site-map.blade.php ENDPATH**/ ?>