


<!-- BEGIN: Vendor JS-->
<script src="<?php echo e(asset('/app-assets/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo e(asset('/app-assets/data/jvector/visitor-data.js')); ?>"></script>
<script src="<?php echo e(asset('/app-assets/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/app-assets/vendors/js/forms/icheck/icheck.min.js')); ?>"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="<?php echo e(asset('/app-assets/js/core/app-menu.js')); ?>"></script>
<script src="<?php echo e(asset('/app-assets/js/core/app.js')); ?>"></script>
<!-- END: Theme JS-->
<script src="<?php echo e(asset('/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js')); ?>"></script>
<!-- BEGIN: Page JS-->
<script src="<?php echo e(asset('/app-assets/js/scripts/pages/dashboard-sales.js')); ?>"></script>
<script src="<?php echo e(asset('/app-assets/js/scripts/forms/validation/form-validation.js')); ?>"></script>
<script src="<?php echo e(asset('/app-assets/js/scripts/tables/datatables/datatable-basic.js')); ?>"></script>
<script src="<?php echo e(asset('/app-assets/js/scripts/forms/checkbox-radio.js')); ?>"></script>
<!-- END: Page JS-->


<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/layout/includes/js.blade.php ENDPATH**/ ?>