 <div class="container">
            <!-- featureds -->
            <div class="section featureds">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="featured-top">
                            <h1><?php echo app('translator')->get('web.recent_ads'); ?></h1>
                        </div>
                    </div>
                </div>
                <!-- featured-slider -->
                

            <div class="featured-slider urgent premim_ads">
              <div class="row" style="margin-right:0px !important;">
                 <?php if($data['recent_ads'] && count($data['recent_ads']) > 0 ): ?>
                        <?php $__currentLoopData = $data['recent_ads']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-3">
                        <div class="featured">
                            <div class="featured-image">
                                <a href="<?php echo e(route('ad.details',['pk_no' => $ad->pk_no, 'url_slug' => $ad->url_slug])); ?>"><img src="<?php echo e(asset('assets/images/default-load.png')); ?>"  data-src="<?php echo e(asset($ad->img_path_thumb)); ?>" alt="<?php echo e($ad->ad_title); ?>" class="img-fluid"></a>
                                <?php if('Urgent' == $ad->promotion): ?>
                                    <span class="featured-ad">Urgent</span>
                                <?php endif; ?>
                            </div>
                            <div class="ad-info">
                                <h3 class="item-price">Rs <?php echo e(number_format($ad->price,2)); ?></h3>
                                <h4 class="item-title"><a href="<?php echo e(route('ad.details',['pk_no' => $ad->pk_no, 'url_slug' => $ad->url_slug])); ?>"><?php echo e($ad->ad_title); ?></a></h4>
                                <div class="item-cat">
                                    <span><a href="<?php echo e(route('ad.details',['pk_no' => $ad->pk_no, 'url_slug' => $ad->url_slug])); ?>"><?php echo e($ad->subcategory->name ?? ''); ?></a></span>
                                </div>
                                <?php
                                $payment = App\Payments::where('f_customer_pk_no',$ad->customer_pk_no)->where('status','VALID')->orderBy('pk_no','desc')->first();
                            ?>
                            <?php if($payment): ?>
                                <div class="premier_ads">
                                    <span class="member">
                                        <i class="fa fa-star"></i>
                                        Member
                                    </span>
                                    <span class="verified">
                                        <i class="fa fa-check"></i>
                                        Verified Seller
                                    </span>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="ad-meta">
                                <div class="meta-content">
                                    <span class="dated"><a href="<?php echo e(route('ad.details',['pk_no' => $ad->pk_no, 'url_slug' => $ad->url_slug])); ?>"><?php echo e(date('d M Y h:i A',strtotime($ad->created_at))); ?> </a></span>
                                </div>

                                <div class="user-option pull-right">
                                    <a href="javascript:void(0)" data-toggle="tooltip" data-placement="top" title="<?php echo e($ad->area->name); ?>, <?php echo e($ad->city_division == 'city' ? $ad->area->city->name : ''); ?> <?php echo e($ad->city_division == 'division' ? $ad->area->division->name : ''); ?>"><i class="fa fa-map-marker"></i> </a>
                                    <!-- <a href="#" data-toggle="tooltip" data-placement="top" title="<?php echo e($ad->user->seller_type ?? ''); ?>"><i class="fa fa-user"></i> </a> -->
                                </div>
                            </div>
                        </div>
                    </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
          </div>

            </div>
        </div>
<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/home/urgent_ads.blade.php ENDPATH**/ ?>