<?php $counter = 0 ;?>
<?php if(Auth::user()): ?>
    <?php
        $counter =  \DB::table('ss_chat')->where('is_seen','0')->where('to_pk_no',Auth::user()->id)->count();
        $payments = App\Payments::where('f_customer_pk_no',Auth::user()->id)->where(['payment_type'=>'package'])->orderBy('pk_no','desc')->first();
    ?>
<?php endif; ?>
<header id="header" class="clearfix">
    <?php
        $setting = App\SiteSetting::first();
    ?>
    <nav class="navbar navbar-default navbar-expand-lg">
        <div class="container">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#tr-mainmenu" aria-controls="tr-mainmenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"><i class="fa fa-align-justify"></i></span>
            </button>
            <?php if(!empty($setting)): ?>
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img class="img-fluid" src="<?php echo e(asset($setting->logo)); ?>" alt="Logo" width="200"></a>
            <?php else: ?>
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img class="img-fluid" src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo"></a>
            <?php endif; ?>
            <div class="collapse navbar-collapse" id="tr-mainmenu">
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo e(route('ads.list')); ?>"><?php echo app('translator')->get('web.all_ads'); ?></a></li>
                </ul>
            </div>
            <div class="nav-right">
                <!-- sign-in -->
                <ul class="chat">
                    <li class="mr-2">
                        <?php if(app()->getLocale() == 'sl'): ?>
                            <a class="language_menu" href="<?php echo e(route('changelang','en')); ?>">English</a>
                        <?php else: ?>
                            <a class="language_menu" href="<?php echo e(route('changelang','sl')); ?>"><?php echo app('translator')->get('web.sin'); ?></a>
                        <?php endif; ?>
                    </li>
                   <!-- <li class="language_dropdown">
                        <div class="">
                            <div class="dropdown">
                              <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                <?php echo e(app()->getLocale() == 'sl' ? 'Sinhala' : 'English'); ?>

                              </button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo e(route('changelang','en')); ?>">English</a>
                                <a class="dropdown-item" href="<?php echo e(route('changelang','sl')); ?>">Sinhala</a>
                              </div>
                            </div>
                        </div>
                    </li>  -->
                    <li><a href="<?php echo e(route('chat')); ?>"> <i class="fa fa-comments <?php echo e($counter > 0 ? 'has-txt-icon' : ''); ?> "></i><?php if($counter > 0 ): ?><span class="chat-counter has-txt"><?php echo e($counter); ?></span> <?php endif; ?></a></li>
                </ul>
                <ul class="sign-in">
                    <?php if(auth()->guard()->guest()): ?>
                        <li><i class="fa fa-user"></i></li>
                        <li><a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('web.login'); ?></a></li>
                        <li><a href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('web.register'); ?></a></li>
                    <?php else: ?>
                        <li><i class="fa fa-user"></i></li>
                        <li class="hidebackslash"><a href="<?php echo e(route('my-dashboard')); ?>"><?php echo app('translator')->get('web.my_account'); ?></a></li>
                    <?php endif; ?>
                </ul>
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn"><?php echo app('translator')->get('web.post_free_ad'); ?></a>
                <?php else: ?>
                    <?php if(!empty($payments)): ?>
                        <?php if($payments->status!="Due"): ?>
                            <a href="javascript:;" data-toggle="modal" data-target="#staticBackdrop" class="btn"><?php echo app('translator')->get('web.post_free_ad'); ?></a>
                        <?php else: ?>
                            <a href="javascript:;" class="btn"><?php echo app('translator')->get('web.pending'); ?></a>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if( Auth::user()->is_verified == 1 ): ?>
                            <a href="javascript:;" data-toggle="modal" data-target="#staticBackdrop" class="btn"><?php echo app('translator')->get('web.post_free_ad'); ?></a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</header><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/layouts/header.blade.php ENDPATH**/ ?>