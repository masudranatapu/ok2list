<?php $__env->startSection('Web Setting','open'); ?>
<?php $__env->startSection('about_us','active'); ?>

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('about.about_title'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page-name'); ?> <?php echo app('translator')->get('about.about_title'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#"><?php echo app('translator')->get('admin_role.breadcrumb_title'); ?>  </a></li>
    <li class="breadcrumb-item active"><?php echo app('translator')->get('about.about_title'); ?>    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_css'); ?>
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-body">
        <section id="pagination">
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-sm">
                        <div class="card-header">
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                <ul class="list-inline mb-0">
                                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-content collapse show">
                            <form action="<?php echo e(route('admin.about.us.update', $about->id)); ?>" enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="card-body card-dashboard">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="package">Main Image</label>
                                                <input type="file" class="form-control" name="image">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <img width="120" class="img-thumbnail" src="<?php echo e(asset($about->image)); ?>" alt="about image">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Details ( En )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="desc"  placeholder="Details English"><?php echo e($about->details_en); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Details ( Sl )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="desc1"  placeholder="Details Sl"><?php echo e($about->details_sl); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Mission ( En )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="mission_en" placeholder="Mission English"><?php echo e($about->mission_en); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Mission ( Sl )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="mission_sl" placeholder="Mission Sl"><?php echo e($about->mission_sl); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Vision ( En )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="vision_en" placeholder="Vision English"><?php echo e($about->vision_en); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Vision ( Sl )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="vision_sl" placeholder="Vision SL"><?php echo e($about->vision_sl); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Our Values ( En )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="our_values_en" placeholder="Our Values English"><?php echo e($about->our_values_en); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="package">Our Values ( Sl )</label>
                                                <textarea cols="30" rows="5" class="form-control" name="our_values_sl" placeholder="Our Values Sl"><?php echo e($about->our_values_sl); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="form-actions text-center mt-3">
                                        <button type="submit" class="btn btn-success mr-1">
                                            Update
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-sm">
                        <div class="card-header">
                            <h4>Demo Image</h4>
                        </div>
                        <div class="card-body">
                            <img width="650" height="1000" src="<?php echo e(asset('assets/direction/about_us.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_js'); ?>
    <script src="<?php echo e(asset('app-assets/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/forms/select/form-select2.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app-assets/pages/customer.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>
    <script>
            CKEDITOR.replace('desc');
            CKEDITOR.replace('desc1');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/web/about.blade.php ENDPATH**/ ?>