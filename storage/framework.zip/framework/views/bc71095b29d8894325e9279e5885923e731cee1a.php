<?php

$old_photos = $row->allPhotos ?? null ;
// echo "<pre>";
// print_r($old_photos[0]->pk_no);
// die();

?>

<div class="row form-group add-image">
   <label class="col-sm-3 label-title">Photos</label>
   <div class="col-sm-9">
      <div class="row">
         <div class="col-md-3 col-sm-4 col-6 img_div_<?php echo e($old_photos[0]->pk_no ?? ''); ?>">
            <?php if($old_photos != null ): ?>
               <?php if(isset($old_photos[0])): ?>
                  <img src="<?php echo e($old_photos[0]->img_path_thumb); ?>" alt="Article Photo" class="img-fluid" height="100px" width="120px"/>
                  <a href="#" class="btn fileupload-exists btn-default btn-rounded  btn-sm photo-delete" data-dismiss="fileupload" data-id="<?php echo e($old_photos[0]->pk_no ?? ''); ?>">
                     <i class="fa fa-times"></i> Remove
                  </a>
               <?php endif; ?>
            <?php endif; ?>
         </div>
         <div class="col-md-3 col-sm-4 col-6 img_div_<?php echo e($old_photos[1]->pk_no ?? ''); ?>">
            <?php if($old_photos != null ): ?>
               <?php if(isset($old_photos[1])): ?>
                  <img src="<?php echo e($old_photos[1]->img_path_thumb); ?>" alt="Article Photo" class="img-fluid" height="100px" width="120px"/>
                  <a href="#" class="btn fileupload-exists btn-default btn-rounded  btn-sm photo-delete" data-dismiss="fileupload" data-id="<?php echo e($old_photos[1]->pk_no ?? ''); ?>">
                     <i class="fa fa-times"></i> Remove
                  </a>
               <?php endif; ?>
            <?php endif; ?>
         </div>
         <div class="col-md-3 col-sm-4 col-6 img_div_<?php echo e($old_photos[2]->pk_no ?? ''); ?>">
            <?php if($old_photos != null ): ?>
               <?php if(isset($old_photos[2])): ?>
                  <img src="<?php echo e($old_photos[2]->img_path_thumb); ?>" alt="Article Photo" class="img-fluid" height="100px" width="120px"/>
                  <a href="#" class="btn fileupload-exists btn-default btn-rounded  btn-sm photo-delete" data-dismiss="fileupload" data-id="<?php echo e($old_photos[2]->pk_no ?? ''); ?>">
                     <i class="fa fa-times"></i> Remove
                  </a>
               <?php endif; ?>
            <?php endif; ?>
         </div>
         <div class="col-md-3 col-sm-4 col-6 img_div_<?php echo e($old_photos[3]->pk_no ?? ''); ?>">
             <?php if($old_photos != null ): ?>
               <?php if(isset($old_photos[3])): ?>
                  <img src="<?php echo e($old_photos[3]->img_path_thumb); ?>" alt="Article Photo" class="img-fluid" height="100px" width="120px"/>
                  <a href="#" class="btn fileupload-exists btn-default btn-rounded  btn-sm photo-delete" data-dismiss="fileupload" data-id="<?php echo e($old_photos[3]->pk_no ?? ''); ?>">
                     <i class="fa fa-times"></i> Remove
                  </a>
               <?php endif; ?>
            <?php endif; ?>
         </div>
      </div>
   </div>
</div>
<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/ad_post/_photo_upload_edit.blade.php ENDPATH**/ ?>