<?php $__env->startPush('custom_css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
<link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<!-- social css -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/solid.css" integrity="sha384-+0VIRx+yz1WBcCTXBkVQYIBVNEFH1eP6Zknm16roZCyeNg2maWEpk/l/KsyFKs7G" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/brands.css" integrity="sha384-1KLgFVb/gHrlDGLFPgMbeedi6tQBLcWvyNUN+YKXbD7ZFbjX6BLpMDf0PJ32XJfX" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/fontawesome.css" integrity="sha384-jLuaxTTBR42U2qJ/pm4JRouHkEDHkVqH0T1nyQXn1mZ7Snycpf6Rl25VBNthU4z0" crossorigin="anonymous">
<?php $__env->stopPush(); ?>
	<?php
		$row = $data['row'];
		$reject_reason  = Config::get('static_arrays.reject_reason') ?? array();
		$cate = DB::table('prd_category')->where('pk_no', $row->f_cat_pk_no)->first();
	?>
<?php $__env->startSection('content'); ?>
<!-- main -->
<section id="main" class="clearfix details-page">
	<div class="container">
		
		<div class="breadcrumb-section">
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
				<li><a href="javascript:;"><?php echo e($cate->name ?? ''); ?></a></li>
				<li><a href="javascript:;"><?php echo e($row->ad_title); ?></a></li>
			</ol>
		</div>

        <?php if(isset($data['detail_page1']) && ($data['detail_page1']) != null ): ?>
         <div class="ads_banner text-center mb-4">
             <a href="<?php echo e($data['detail_page1']->link); ?>" target="_blank" title="<?php echo e($data['detail_page1']->name); ?>"><img src="<?php echo e(fileExit($data['detail_page1']->photo)); ?>" class="w-100" alt="<?php echo e($data['detail_page1']->name); ?>" style="height: 96px;"></a>
         </div>
         <?php endif; ?>

		<div class="section slider">
			<div class="row">
				<!-- carousel -->
				<div class="col-lg-7">
					<div id="product-carousel" class="carousel slide" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators">
							<?php if($data['photos'] && count($data['photos']) > 0 ): ?>
							<?php $__currentLoopData = $data['photos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li data-target="#product-carousel" data-slide-to="<?php echo e($key); ?>" class="active">
								<img src="<?php echo e(asset('uploads/product/'.$row->pk_no.'/small/'.$photo->img_name)); ?>" alt="<?php echo e($row->ad_title); ?>" class="img-fluid" >
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</ol>
						<!-- Wrapper for slides -->
						<div class="carousel-inner" role="listbox">
							<?php if($data['photos'] && count($data['photos']) > 0 ): ?>
							<?php $__currentLoopData = $data['photos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item carousel-item <?php echo e($key == 0 ? 'active' : ''); ?> ">
								<div class="carousel-image">
									<a class="popup" href="<?php echo e(asset('uploads/product/'.$row->pk_no.'/'.$photo->img_name)); ?>"><img src="<?php echo e(asset('uploads/product/'.$row->pk_no.'/'.$photo->img_name)); ?>" alt="<?php echo e($row->ad_title); ?>" alt="Featured Image" class="img-fluid"></a>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
							</div><!-- carousel-inner -->
							<!-- Controls -->
							<a class="left carousel-control" href="#product-carousel" role="button" data-slide="prev">
								<i class="fa fa-chevron-left"></i>
							</a>
							<a class="right carousel-control" href="#product-carousel" role="button" data-slide="next">
								<i class="fa fa-chevron-right"></i>
								</a><!-- Controls -->
							</div>
							</div><!-- Controls -->
							<!-- slider-text -->
							<div class="col-lg-5">
								<div class="slider-text">
									<h2>
										Rs <?php echo e(number_format($row->price,2)); ?>

										<div class="float-right">
											
											<?php if($row->is_like == '1'): ?>
											<a href="<?php echo e(route('ad-post-dislike', $row->pk_no)); ?>" class="like_ads btn-sm" title="Like"><i class="fa fa-thumbs-up"></i>
												<?php echo e($data['like_count'] ?? '0'); ?>

											</a>
											<?php else: ?>
											<a href="<?php echo e(route('ad-post-like', $row->pk_no)); ?>" class="like_ads btn-sm" title="Like"><i class="fa fa-thumbs-up"></i>
												<?php echo e($data['like_count'] ?? '0'); ?>

											</a>
											<?php endif; ?>
										</div>
									</h2>
									<h3 class="title">
										<?php echo e($row->ad_title); ?>

									</h3>
									<p><span>Offered by : <a href="javascript:void(0)"><?php echo e($row->user->name ?? ''); ?></a></span>
									<span>
										Ad ID :<a href="javascript:void(0)" class="time"> <?php echo e($row->code); ?></a></span></p>
										<span class="icon"><i class="fa fa-clock-o"></i><a href="javascript:void(0)"> <?php echo e(date('d M, y h:i A',strtotime($row->created_at))); ?></a></span>
										<span class="icon"><i class="fa fa-map-marker"></i><a href="javascript:void(0)"><?php echo e($row->area->name ?? ''); ?>, <?php echo e($row->area->city->name ?? ''); ?><?php echo e($row->division->name ?? ''); ?></a></span>
										<?php if(($row->user->package != null ) && (!empty($row->user->shop ))): ?>
										
										<?php
											$payment = App\Payments::where('f_customer_pk_no',$row->customer_pk_no)->where('status','VALID')->orderBy('pk_no','desc')->first();
										?>
										<?php if($payment): ?>
										<div class="">
											<div class="premier_ads">
			                                    <span class="member">
			                                        <i class="fa fa-star"></i>
			                                        Member
			                                    </span>
			                                    <span class="verified">
			                                        <i class="fa fa-check"></i>
			                                        Verified Seller
			                                    </span>
			                                    <strong><a href="#">(Visit member's shop)</a></strong>
			                                </div>
										</div>
										<?php endif; ?>
										<?php else: ?>
										<span class="icon"><i class="fa fa-suitcase online"></i><a href="javascript:void(0)"><?php echo e($row->user->seller_type); ?></a></span>
										<?php endif; ?>
										<!-- short-info -->
										<div class="short-info">
											<h4>Short Info</h4>
											<?php if($row->using_condition): ?>
											<p><strong>Condition: </strong><a href="#"><?php echo e($row->using_condition); ?></a> </p>
											<?php endif; ?>
											<?php if($row->brand_name): ?>
											<p><strong>Brand: </strong><a href="#"><?php echo e($row->brand_name); ?></a> </p>
											<?php endif; ?>
											<?php if($row->prod_feature): ?>
											<p><strong>Features: </strong> <?php echo e($row->prod_feature); ?> </p>
											<?php endif; ?>
											<?php if($row->model_name): ?>
											<p><strong>Model: </strong><a href="#"><?php echo e($row->model_name); ?></a></p>
											<?php endif; ?>
											</div><!-- short-info -->
											<!-- contact-with -->
											<div class="contact-with">
												<h4>Contact with </h4>
												<span class="btn btn-red show-number">
													<i class="fa fa-phone-square"></i>
													<span class="hide-text">Click to show phone number </span>
													<?php if($row->mobile1): ?>
													<span class="hide-number"><a href="tel:<?php echo e($row->mobile1); ?>"><?php echo e($row->mobile1); ?></a></span>
													<?php endif; ?>
													<?php if($row->mobile2): ?>
													<span class="hide-number"><a href="tel:<?php echo e($row->mobile2); ?>"><?php echo e($row->mobile2); ?></a></span>
													<?php endif; ?>
												</span>

												<?php if(Auth::user()): ?>
												<?php if( Auth::user()->id != $row->customer_pk_no ): ?>
												<a href="javascript:void(0)"  id="chat_dalal" class="btn" data-toggle="modal" data-target="#chatModal" data-pid="<?php echo e($row->pk_no); ?>" data-toid="<?php echo e(Auth::user()->id); ?>"><i class="fa fa-comments"></i>Chat</a>
												<?php endif; ?>
												<?php else: ?>
												<a href="<?php echo e(route('login')); ?>?referer=<?php echo e(request()->fullUrl()); ?>" class="btn" ><i class="fa fa-comments"></i>Chat</a>
												<?php endif; ?>

											</div>
											<!-- social-links -->
											<div class="social-links">
												<h4 style="margin-bottom: 0px;">Share this ad</h4>
												<div id="shareBlock"></div>
												</div><!-- social-links -->
											</div>
											</div><!-- slider-text -->
										</div>
									</div>
									<!-- slider -->
									<div class="description-info">
										<div class="row">
											<!-- description -->
											<div class="col-md-8">
												<div class="row">
													<div class="col-12">
														<div class="description">
															<h4>Description</h4>
															<div class="aaa">
																<p><?php echo $row->description ; ?></p>
															</div>
														</div>
													</div>
													<div class="col-12">
														<div class="section recommended-ads">
															<div class="featured-top">
																<h4>Recommended Ads for You</h4>
															</div>
															<?php if(isset($data['similar_ads']) && count($data['similar_ads']) > 0 ): ?>
															<?php $__currentLoopData = $data['similar_ads']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $srow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<div class="ad-item row col-12">
																<div class="item-image-box col-lg-4">
																	<div class="item-image">
																		<a  href="<?php echo e(route('ad.details',['pk_no' => $srow->pk_no,'url_slug' => $srow->url_slug])); ?>" title="<?php echo e($srow->ad_title); ?>"><img src="<?php echo e(asset($srow->img_path_thumb)); ?>" alt="Image" class="img-fluid"></a>
																	</div>
																</div>
																<div class="item-info col-lg-8">
																	<div class="ad-info">
																		<h3 class="item-price">
																			Rs <?php echo e(number_format($srow->price,2)); ?>

																			<div class="float-right">

																				<?php if($row->is_like == '1'): ?>
																					<a href="<?php echo e(route('ad-post-dislike', $row->pk_no)); ?>" class="like_ads btn-sm" title="Like"><i class="fa fa-thumbs-up"></i>
																						<?php echo e($data['like_count'] ?? '0'); ?>

																					</a>
																				<?php else: ?>
																				<a href="<?php echo e(route('ad-post-like', $row->pk_no)); ?>" class="like_ads btn-sm" title="Like"><i class="fa fa-thumbs-up"></i>
																					<?php echo e($data['like_count'] ?? '0'); ?>

																				</a>
																				<?php endif; ?>

																			</div>
																		</h3>
																		<h4 class="item-title"><a href="<?php echo e(route('ad.details',['pk_no' => $srow->pk_no,'url_slug' => $srow->url_slug])); ?>" title="<?php echo e($srow->ad_title); ?>"><?php echo e($srow->ad_title); ?></a></h4>
																		<div class="item-cat">
																			<span><a href="javascript:void(0)"><?php echo e($srow->category->name ?? ''); ?></a></span> /
																			<span><a href="javascript:void(0)"><?php echo e($srow->subcategory->name ?? ''); ?></a>&nbsp;&nbsp; </span>
																		</div>
																	</div>
																	<div class="ad-meta">
																		<div class="meta-content">
																			<span class="dated"><?php echo e(date('d M, Y H:i A',strtotime($srow->created_at))); ?></span>
																			<?php if($srow->useing_codition): ?>
																			<a href="javascript:void(0)" class="tag"><i class="fa fa-tags"></i> <?php echo e($srow->using_condition); ?></a>
																			<?php endif; ?>
																		</div>
																		<div class="user-option pull-right">
																			<a href="#" data-toggle="tooltip" data-placement="top" title="<?php echo e($srow->area->name ?? ''); ?>, <?php echo e($srow->area->city->name ?? ''); ?> <?php echo e($srow->area->division->name ?? ''); ?>"><i class="fa fa-map-marker"></i> </a>
																			<a class="online" href="#" data-toggle="tooltip" data-placement="top" title="<?php echo e($srow->user->seller_type ?? ''); ?>"><i class="fa fa-user"></i> </a>
																		</div>
																	</div>
																</div>
															</div>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
														</div>
													</div>
												</div>
											</div>
											<?php if(Auth::user() && (Auth::user()->id == $row->customer_pk_no)): ?>
											<!-- NO  -->
											<?php else: ?>
											<div class="col-md-4">
												<div class="row">
													<div class="col-12">
														<div class="short-info" style="margin-top: 0px;">
															<ul>
																<?php if( Auth::user() ): ?>
																<?php if($row->is_favorite == 1 ): ?>
																<li><i class="fa fa-heart-o"></i><a href="javascript:void(0)">Added as Favorite</a></li>
																<?php else: ?>
																<li><i class="fa fa-heart-o"></i><a href="javascript:void(0)" id="save_as_fav" data-adid="<?php echo e($row->pk_no); ?>" data-uid="<?php echo e(Auth::user()->id ?? ''); ?>">Save ad as Favorite</a></li>
																<?php endif; ?>
																<?php else: ?>
																<li><i class="fa fa-heart-o"></i><a href="javascript:void(0)" onclick="return confirm('Please login first!');">Save ad as Favorite</a></li>
																<?php endif; ?>
																<li><i class="fa fa-exclamation-triangle"></i><a data-toggle="modal" data-target="#reportad" href="javascript:void(0)">Report this ad</a></li>
																</ul><!-- social-icon -->
															</div>
														</div>



                                                        <?php if(isset($data['detail_page3']) && ($data['detail_page3']) != null ): ?>
														<div class="col-12">
															<div class="banner_ads short-info">
                                                                <a href="<?php echo e($data['detail_page3']->link); ?>" target="_blank" title="<?php echo e($data['detail_page3']->name); ?>"><img src="<?php echo e(fileExit($data['detail_page3']->photo)); ?>" class="w-100" alt="<?php echo e($data['detail_page3']->name); ?>" style="height: 480px;"></a>
															</div>
														</div>
                                                        <?php endif; ?>

													</div>
												</div>
												<?php endif; ?>
												<!-- description -->
												</div><!-- row -->
												</div><!-- description-info -->



                                                <?php if(isset($data['detail_page2']) && ($data['detail_page2']) != null ): ?>
                                                <div class="container mb-4">
                                                     <div class="ads_banner text-center mb-5">
                                                         <a href="<?php echo e($data['detail_page2']->link); ?>" target="_blank" title="<?php echo e($data['detail_page2']->name); ?>"><img src="<?php echo e(fileExit($data['detail_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['detail_page2']->name); ?>" style="height: 96px;"></a>
                                                     </div>
                                                 </div>
                                                 <?php endif; ?>





												<div class="recommended-info">
													<div class="row">
														</div><!-- row -->
														</div><!-- recommended-info -->
														</div><!-- container -->
														</section><!-- main -->
														<!-- download -->
														<section id="something-sell" class="clearfix parallax-section">
															<div class="container">
																<div class="row">
																	<div class="col-sm-12 text-center">
																		<h2 class="title">Do you have something-sell?</h2>
																		<h4>Post your ad for free on gogoads.lk</h4>
																		<a href="#" data-toggle="modal" data-target="#staticBackdrop" class="btn btn-primary">Post Your Ad</a>
																	</div>
																	</div><!-- row -->
																	</div><!-- contaioner -->
																	</section><!-- download -->
																	<!-- Modal Report ads-->
																	<div class="modal fade categoryselectmodal" id="reportad" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
																		<div class="modal-dialog">
																			<div class="modal-content">
																				<div class="modal-header">
																					<p class="modal-title" id="staticBackdropLabel"><strong>Is there something wrong with this ad?</strong></p>
																					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																					<span aria-hidden="true">&times;</span>
																					</button>
																				</div>
																				<div class="modal-body">
																					<p>
																						We're constantly working hard to assure that our ads meet high standards and we are very grateful for any kind of feedback from our users.
																						If you find any inconvinence with this ads kindly inform us.
																					</p><hr>
																					<div class="user-account" style="padding: 20px;">
																						<?php echo Form::open([ 'route' => ['ad.report', $row->pk_no], 'method' => 'post', 'class' => 'form-horizontal', 'files' => true , 'novalidate', 'autocomplete' => 'off']); ?>

																						<div class="form-group <?php echo $errors->has('reject_reason') ? 'error' : ''; ?>">
																							<label for="reason">Reason</label>
																							<div class="controls">
																								<?php echo Form::select('reject_reason', $reject_reason, old('reject_reason'), ['class'=>'form-control select2', 'id' => 'reject_reason','data-validation-required-message' => 'This field is required', 'placeholder' => 'Select reason', 'tabindex' => 2,  ]); ?>

																								<?php echo $errors->first('reject_reason', '<label class="help-block text-danger">:message</label>'); ?>

																							</div>
																						</div>
																						<div class="form-group <?php echo $errors->has('email') ? 'error' : ''; ?>">
																							<label for="exampleFormControlSelect1">Email</label>
																							<div class="controls">
																								<?php echo Form::email('email', null, [ 'class' => 'form-control', 'data-validation-required-message' => 'This field is required', 'maxlength' => '50', 'data-validation-maxlength-message' => 'Maxlength 50 characters', 'placeholder' => 'Enter email', 'tabindex' => 2]); ?>

																								<?php echo $errors->first('email', '<label class="help-block text-danger">:message</label>'); ?>

																							</div>
																						</div>
																						<div class="form-group <?php echo $errors->has('message') ? 'error' : ''; ?>">
																							<div class="controls">
																								<?php echo Form::textarea('message', null, [ 'class' => 'form-control ctext', 'maxlength' => '50', 'data-validation-maxlength-message' => 'Maxlength 50 characters', 'placeholder' => 'Enter message', 'tabindex' => 3, 'rows' => 3]); ?>

																								<?php echo $errors->first('message', '<label class="help-block text-danger">:message</label>'); ?>

																							</div>
																						</div>
																						<button type="submit" class="btn" style="width: 100%;">Submit</button>
																						<?php echo Form::close(); ?>

																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																	<?php if(Auth::user()): ?>
																	<!-- Modal Report ads-->
																	<div class="modal fade" id="chatModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticchatLabel" aria-hidden="true">
																		<div class="modal-dialog modal-lg">
																			<div class="modal-content">
																				<div class="modal-header">
																					<p class="modal-title" id="staticchatLabel">Chat with <?php echo e($row->user->name ?? ''); ?> </p>
																					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																					<span aria-hidden="true">&times;</span>
																					</button>
																				</div>
																				<div class="modal-body">
																					<div class="row justify-content-center chatinterface  mt-15">
																						<div class="col-md-12 chat">
																							<div class="card">
																								<div class="card-header msg_head">
																									<div class="d-flex bd-highlight">
																										<div class="media p-1">
																											<img src="<?php echo e(asset('uploads/product/'.$row->pk_no.'/thumb/'.$row->thumb)); ?>" alt="<?php echo e($row->user->name ?? ''); ?>" class="mr-3" style="height:60px;">
																											<div class="media-body">
																												<h5 style="font-size: 16px; color: #000; margin-bottom: 2px; margin-top: 3px;"><?php echo e($row->ad_title); ?></h5>
																												<p class="mb-0"><?php echo e($row->area->name ?? ''); ?>, <?php echo e($row->area->city->name ?? ''); ?><?php echo e($row->division->name ?? ''); ?></p>
																												<p class="mb-0 text-success">Rs <?php echo e(number_format($row->price,2)); ?></p>
																											</div>
																										</div>
																									</div>
																								</div>
																								<div class="card-body msg_card_body" id="msg_card_body">
																									<?php if($data['all_text'] && count($data['all_text']) > 0 ): ?>
																									<?php $__currentLoopData = $data['all_text']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $txt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																									<?php if($txt->customer_pk_no == $row->customer_pk_no): ?>
																									<div class="d-flex justify-content-start mb-4">
																										<div class="msg_cotainer">
																											<?php echo e($txt->message); ?>

																											<span class="msg_time_send"><?php echo e(date('d M, y, h:i A', strtotime($txt->created_at))); ?></span>
																										</div>
																									</div>
																									<?php endif; ?>
																									<?php if($txt->customer_pk_no == Auth::user()->id): ?>
																									<div class="d-flex justify-content-end mb-4">
																										<div class="msg_cotainer_send">
																											<?php echo e($txt->message); ?>

																											<span class="msg_time_send"><?php echo e(date('d M, y, h:i A', strtotime($txt->created_at))); ?></span>
																										</div>
																									</div>
																									<?php endif; ?>
																									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																									<?php endif; ?>
																								</div>
																								<div class="card-footer">
																									<?php echo Form::open([ 'route' => 'chat.store', 'method' => 'post', 'class' => 'form-horizontal', 'id' => 'frmSmg','files' => true , 'novalidate', 'autocomplete' => 'off']); ?>

																									<input type="hidden" name="postid" value="<?php echo e($row->pk_no); ?>" id="postid" />
																									<input type="hidden" name="to_user" value="<?php echo e($row->customer_pk_no); ?>" id="to_user" />
																									<div class="form-group" id="textfg">
																										<div class="input-group">
																											<textarea name="message" class="form-control type_msg" placeholder="Type your message..." id="textSmg"></textarea>
																											<div class="input-group-append">
																												<span class="input-group-text send_btn" id="sendSmg"><i class="fa fa-location-arrow"></i></span>
																											</div>
																										</div>
																									</div>
																									<?php echo Form::close(); ?>

																								</div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																	<?php endif; ?>
																	<?php $__env->stopSection(); ?>
																	<?php $__env->startPush('custom_js'); ?>
																	<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
																	<!-- social js -->
																	<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.13.1/highlight.min.js"></script>
																	<!-- social js -->
																	<script src="<?php echo e(asset('/assets/js/social-share/share-helper.js')); ?>"></script>
																	<script src="<?php echo e(asset('/assets/js/social-share/share-main.js')); ?>"></script>
																	<script type="text/javascript">
																		$(document).on('click', '#save_as_fav', function(e){
																					var adid 	= $(this).data('adid');
																					var uid 	= $(this).data('uid');
																			var pageurl = `<?php echo e(URL::to('/favorite-ad')); ?>`;
																			$.ajax({
																				type :'post',
																				data :{'adid' : adid, '_token': "<?php echo e(csrf_token()); ?>" },
																				url  :pageurl,
																				async :true,
																				beforeSend: function ()
																				{
																					$("body").css("cursor", "progress");
																				},
																				success: function (data)
																				{
																					if(data.status == true ){
																						toastr.success(data.msg);
																						$('#save_as_fav').text('Added as favorite');
																					} else {
																						toastr.error(data.msg);
																					}
																				},
																				complete: function (data)
																				{
																					$("body").css("cursor", "default");
																				}
																			});
																		})
                                                                        jQuery(function($) {
                                                                          $('.aaa').each(function(){
                                                                            var show_char = 20;
                                                                            var ellipses = "... ";
                                                                            var content = $(this).html();

                                                                            if (content.trim().length > show_char) {
                                                                              var a = content.trim().substr(3, show_char); // use 3 to avoid <p>
                                                                              var b = content.trim().substr(show_char - content.trim().length).replace('</p>' , '');  // replace the last </p>
                                                                              var html = a + "<span class='truncated'>" + ellipses + "</span><span class='truncated' style='display:none'>" + b + "</span><a class='read-more' href='#'>Read more</a>";
                                                                              // wrap the a into `<p></p>` then append the read more to it
                                                                              $(this).html('<p>' + html  + '</p>');
                                                                            }
                                                                          });

                                                                          $(".read-more").click(function(e) {
                                                                            e.preventDefault();
                                                                            $(this).text( ( i , v) => v == "Read more" ? "..Read Less" : "Read more"); //change here..
                                                                            $(this).closest(".aaa").find(".truncated").toggle();
                                                                          });
                                                                        });
																	</script>

																	<?php if(Auth::user()): ?>

																	<?php echo $__env->make('chat._chat_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
																	<?php endif; ?>
																	<script>
																		$('.popup').magnificPopup({
																			type: 'image',
																			gallery: {
																				enabled:true
																			},
																			zoom: {
																				enabled: true,
																				duration: 300,
																			}
																		});
																	</script>
																	<script>
																	hljs.initHighlightingOnLoad();
																	$('#shareBlock').cShare({
																	description: 'jQuery plugin - C Share buttons...',
																	showButtons: ['fb', 'line', 'plurk', 'weibo', 'twitter', 'tumblr', 'email']
																	});
																		$(document).on('click', '#key_search', function(e){
																			var keywords = $('#keywords').val();

																			var new_url = old_url = `<?php echo e(route('ads.list')); ?>`;
																			new_url = makeUrl(new_url, 'keywords' , keywords);

																			window.location.href = new_url;
																		})
																		$(document).on('change', '#short_by_select', function(e){
																					var short_by 	= $(this).val();
																					var new_url 	= old_url = $(location).attr("href");
																							var param 		= $(this).val();
																									var arr 			= param.split('_');
																							var order 		= arr[0];
																									var sort 			= arr[1];
																									var val 			= 0;
																			new_url = makeUrl(old_url, 'sort' , order);
																			new_url = makeUrl(new_url, 'order' , sort);
																			window.location.href = new_url;
																		})
																		$(document).on('click','.filter_by',function(e){
																			var new_url = old_url = $(location).attr("href");
																					var param 	= $(this).val();
																							var val 		= 0;
																			if($(this).is(":checked")){
																				var val = 1;
																				var new_url = makeUrl(old_url, param, val);
																					}	else{
																				var val = 0;
																				var new_url = makeUrl(old_url, param, val);
																				}
																				new_url = makeUrl(new_url, 'page' , 1);
																			window.location.href = new_url;

																		})
																		function makeUrl(old_url,param,val)
																		{
																													var url 					= new URL(old_url);
																			var search_params = url.searchParams;
																			search_params.set(param, val);
																											url.search 				= search_params.toString();
																			return url.toString();
																		}
																	</script>
																	<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/ads/details.blade.php ENDPATH**/ ?>