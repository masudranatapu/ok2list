<?php $__env->startSection('Web Setting','open'); ?>

<?php $__env->startSection('howto_sell_first','active'); ?>

<?php $__env->startSection('title'); ?>
    how to sell fast
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name'); ?>
    how to sell fast
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="#"><?php echo app('translator')->get('admin_role.breadcrumb_title'); ?>  </a></li>
    <li class="breadcrumb-item active">how to sell fast    </li>
<?php $__env->stopSection(); ?>

<!--push from page-->
<?php $__env->startPush('custom_css'); ?>
    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-body">
        <section id="pagination">
            <div class="row">
                <div class="col-md-6">
                    <div class="card card-sm">
                        <div class="card-header">
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                <ul class="list-inline mb-0">
                                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                                </ul>
                            </div>
                        </div>

                        <?php echo Form::open([ 'route' => 'admin.howtosell.fast.store', 'method' => 'post', 'class' => 'form-horizontal', 'files' => true , 'novalidate', 'autocomplete' => 'off']); ?>


                        <div class="card-content collapse show">
                            <div class="card-body card-dashboard">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="package">Description (En)</label>
                                            <textarea name="desc"><?php echo $data['row']->description ?? null; ?></textarea>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="package">Description One (SL)</label>
                                            <textarea name="desc1"><?php echo $data['row']->description_sl ?? null; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="form-actions text-center mt-3">
                                    <a href="">
                                        <button type="submit" class="btn btn-success mr-1">Update</button>
                                    </a>

                                </div>

                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-sm">
                        <div class="card-header">
                            <h4>Demo Image</h4>
                        </div>
                        <div class="card-body">
                            <img width="650" height="1000" src="<?php echo e(asset('assets/direction/howtosell.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<!--push from page-->
<?php $__env->startPush('custom_js'); ?>
    <script src="<?php echo e(asset('app-assets/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/forms/select/form-select2.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app-assets/pages/customer.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>
    <script>
            CKEDITOR.replace('desc');
            CKEDITOR.replace('desc1');
            // CKEDITOR.replace('desc2');
            // CKEDITOR.replace('desc3');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/web/how-to-sell.blade.php ENDPATH**/ ?>