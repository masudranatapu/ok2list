<?php
   $old_photos = $row->allPhotos ?? null ;
?>

<div class="row form-group add-image">
   <label class="col-sm-3 label-title">Photos for your ad<span class="required">*</span></label>
   <div class="col-sm-9">
      <div class="input-images-2"></div>
   </div>
</div><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/ad_post/_photo_upload.blade.php ENDPATH**/ ?>