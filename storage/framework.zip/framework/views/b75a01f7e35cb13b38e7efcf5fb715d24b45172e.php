<div class="container">
    <div class="section category-ad text-center">
        <div class="row">
            <div class="col-sm-12">
                <div class="featured-top">
                    <h1><?php echo app('translator')->get('web.popular_categories'); ?></h1>
                </div>
            </div>
        </div>
        <ul class="category-list">
            
            <div class="row no-gutters">
                <?php if($data['top_categories'] && count($data['top_categories']) > 0 ): ?>
                <?php $__currentLoopData = $data['top_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-4 col-xl-3">
                    <div class="category-item">
                        <div class="<?php echo e($cat->url_slug); ?>">
                            <a href="<?php echo e(route('ads.list', ['area' => 'srilanka', 'category' => $cat->url_slug])); ?>">
                                <div class="category-icon"><img src="<?php echo e(asset($cat->icon_src)); ?>" alt="images" class="img-fluid" ></div>
                                <span class="category-title" style="color:#000000;">
                                    <?php if($cat->url_slug == 'property'): ?>
                                    Property
                                    <?php elseif($cat->url_slug == 'electronics-gedgets'): ?>
                                    Electronics
                                    <?php else: ?>
                                    <?php echo e($cat->name); ?>

                                    <?php endif; ?>
                                </span>
                                <span class="category-quantity" style="color:#000000;">(<?php echo e($cat->total_post); ?>)</span>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            
            
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/home/popular_category.blade.php ENDPATH**/ ?>