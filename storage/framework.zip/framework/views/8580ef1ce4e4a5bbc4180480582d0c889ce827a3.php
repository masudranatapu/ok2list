<?php $__env->startSection('content'); ?>
	<section id="main" class="clearfix ad-details-page">
		<div class="container">
			<div class="breadcrumb-section">
				<ol class="breadcrumb">
					<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
					<li><?php echo app('translator')->get('web.membership'); ?></li>
				</ol>
			</div>
			<?php if(isset($data['membership_page1']) && ($data['membership_page1']) != null ): ?>
				<div class="container">
					<div class="ads_banner text-center mb-4">
						<a href="<?php echo e($data['membership_page1']->link); ?>" target="_blank" title="<?php echo e($data['membership_page1']->name); ?>"><img src="<?php echo e(fileExit($data['membership_page1']->photo)); ?>" class="w-100" alt="<?php echo e($data['membership_page1']->name); ?>" style="height: 96px;"></a>
					</div>
				</div>
			<?php endif; ?>
			<div class="ads-info">
				<div class="row">
					<div class="col-md-8">
						<div class="my-ads section">
							<h4><?php echo app('translator')->get('web.membership'); ?></h4>
							<div id="page-content">
								<?php if($data['membership']): ?>
									<?php if(app()->getLocale() == 'en'): ?>
										<p><?php echo $data['membership']->description; ?></p>
									<?php else: ?>
										<p><?php echo $data['membership']->description_sl; ?></p>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-md-4 text-center">
						<div class="recommended-cta">
							<div class="cta">
								<!-- single-cta -->
								<div class="single-cta">
									<!-- cta-icon -->
									<div class="cta-icon icon-secure">
										<img src="<?php echo e(asset('assets/images/icon/13.png')); ?>" alt="Icon" class="img-fluid">
									</div><!-- cta-icon -->

									<h4><?php echo app('translator')->get('web.secure_trading'); ?></h4>
									<?php if($data['sidebar']): ?>
										<?php if(app()->getLocale() == 'en'): ?>
											<p><?php echo $data['sidebar']->secure_trading_en; ?></p>
										<?php else: ?>
											<p><?php echo $data['sidebar']->secure_trading_sl; ?></p>
										<?php endif; ?>
									<?php endif; ?>
								</div><!-- single-cta -->
								<!-- single-cta -->
								<div class="single-cta">
									<!-- cta-icon -->
									<div class="cta-icon icon-support">
										<img src="<?php echo e(asset('assets/images/icon/14.png')); ?>" alt="Icon" class="img-fluid">
									</div><!-- cta-icon -->

									<h4><?php echo app('translator')->get('web.support'); ?></h4>
									<?php if($data['sidebar']): ?>
										<?php if(app()->getLocale() == 'en'): ?>
											<p><?php echo $data['sidebar']->support_en; ?></p>
										<?php else: ?>
											<p><?php echo $data['sidebar']->support_sl; ?></p>
										<?php endif; ?>
									<?php endif; ?>
								</div><!-- single-cta -->


								<!-- single-cta -->
								<div class="single-cta">
									<!-- cta-icon -->
									<div class="cta-icon icon-trading">
										<img src="<?php echo e(asset('assets/images/icon/15.png')); ?>" alt="Icon" class="img-fluid">
									</div><!-- cta-icon -->

									<h4><?php echo app('translator')->get('web.easy_trading'); ?></h4>
									<?php if($data['sidebar']): ?>
										<?php if(app()->getLocale() == 'en'): ?>
											<p><?php echo $data['sidebar']->easy_trading_en; ?></p>
										<?php else: ?>
											<p><?php echo $data['sidebar']->easy_trading_sl; ?></p>
										<?php endif; ?>
									<?php endif; ?>
								</div><!-- single-cta -->

								<!-- single-cta -->
								<div class="single-cta">
									<h4><?php echo app('translator')->get('web.need_help'); ?></h4>
									<p>info@gogoads.lk</p>
								</div><!-- single-cta -->
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php if(isset($data['membership_page2']) && ($data['membership_page2']) != null ): ?>
				<div class="container">
					<div class="ads_banner text-center mb-4">
						<a href="<?php echo e($data['membership_page2']->link); ?>" target="_blank" title="<?php echo e($data['membership_page2']->name); ?>"><img src="<?php echo e(fileExit($data['membership_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['membership_page2']->name); ?>" style="height: 96px;"></a>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_footer_script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/common/get_membership.blade.php ENDPATH**/ ?>