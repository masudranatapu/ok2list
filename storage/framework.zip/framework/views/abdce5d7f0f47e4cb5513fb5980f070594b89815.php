<?php $__env->startPush('custom_css'); ?>

<link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<style type="text/css">
	.c-btn {
	    color: #fff;
	    font-weight: 400;
	    font-size: 14px;
	    background: #ea710a;
	    padding: 0px 10px;
	    border-radius: 4px;
	}
  .c-btn:hover{
  		color: #000;
	}
	.ad-info .item-price{display: inline-block;margin-bottom: 8px;}
	.promote {text-align: left;}

</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<?php
	$rows = $data['my_ads'] ?? null;
?>

<!-- myads-page -->
<section id="main" class="clearfix myads-page">
	<div class="container">

		<div class="breadcrumb-section">
			<ol class="breadcrumb">
				<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
				<li>Ad Post</li>
			</ol>
		</div>

		<div class="ads-info profile">
			<div class="row">
				<div class="col-md-4 text-center">
					<!-- header -->
					<?php echo $__env->make('users._user_dashboard_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- end header -->
				</div>
				<div class="col-md-8">
					<div class="my-ads section">
						<h2>My ads</h2>
						<!-- ad-item -->
						<?php if( $rows && count($rows) > 0 ): ?>
						<?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<div class="ad-item row col-12">
							<div class="item-image-box col-lg-4">
								<div class="item-image">
									<a href="javascript:void(0)"><img src="<?php echo e($row->img_path_thumb ?? ''); ?>" alt="Image" class="img-fluid" style="width: 100%; height: 150px;"></a>
								</div>
							</div>

							<div class="item-info col-lg-8">
								<div class="ad-info">
									<h3 class="item-price">Rs <?php echo e(number_format($row->price,2)); ?> <a href="<?php echo e(route('promoted-ads.create',$row->pk_no)); ?>">(Promote this ad)</a></h3>

                                    <?php if($row->is_delete == 1): ?>
                                    <a href="javascript:void(0)"  class="pull-right c-btn"> Rejected</a>
                                    <?php else: ?>
                                        <?php if($row->is_active == 0 ): ?>
                                        <a href="javascript:void(0)"  class="pull-right c-btn"> Pending</a>
                                        <?php elseif($row->is_active == 1): ?>
                                        <a href="javascript:void(0)"  class="pull-right c-btn"> <?php echo e($row->promotion); ?> </a>
                                        <?php elseif($row->is_active == 2): ?>
                                        <a href="javascript:void(0)"  class="pull-right c-btn btn-danger">Expired</a>
                                        <?php elseif($row->is_active == 3): ?>
                                        <a href="javascript:void(0)"  class="pull-right c-btn btn-danger">Draft</a>

                                        <?php endif; ?>
									<?php endif; ?>

									<h4 class="item-title"><a href="<?php echo e(route('ad.details',['pk_no' => $row->pk_no,'url_slug' => $row->url_slug])); ?>"><?php echo e($row->ad_title ?? ''); ?></a></h4>
									<div class="item-cat">
										<span><a href="javascript:void(0)"><?php echo e($row->category->name ?? ''); ?></a></span> /
										<span><a href="javascript:void(0)"><?php echo e($row->subcategory->name ?? ''); ?></a></span>
									</div>
								</div>
								<?php
									$ss_packages = DB::table('ss_packages')->where('pk_no', Auth::user()->package_id)->first();
								?>
								<div class="ad-meta">
									<div class="meta-content">
										<span class="dated" style="">Posted On: <a href="#"><?php echo e(date('d M Y, H:i A ', strtotime($row->created_at))); ?></a></span>
										<?php if($ss_packages->analytics == 1): ?>
											<span class="visitors">Visitors: <?php echo e($row->total_view ?? '0'); ?></span>
											<span class="visitors">Likes: <?php echo e($row->total_like ?? '0'); ?></span>
										<?php endif; ?>
									</div>

									<div class="user-option pull-right">
										
										<a class="edit-item" href="<?php echo e(route('edit-post',['id' => $row->pk_no, 'subcategory' => $row->subcategory->url_slug,'type' => $row->main_category, 'category' => $row->f_scat_pk_no])); ?>" data-toggle="tooltip" data-placement="top" title="Edit this ad"><i class="fa fa-pencil"></i></a>
										<a class="delete-item" href="<?php echo e(route('my-ads.delete',[$row->pk_no])); ?>" data-toggle="tooltip" data-placement="top" title="Delete this ad" onclick="return confirm('Are you sure ?')"><i class="fa fa-times"></i></a>
									</div>
								</div>
							</div>
						</div>
						<?php if($row->is_active == 2): ?>
						<p><b>Reason for reject :</b> <span class="text-danger"><?php echo e($row->comments); ?></span></p>
						<?php endif; ?>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="row">
							<div class="col-lg-12">
								<div class="text-center">
									<?php echo e($rows->appends(request()->query())->links()); ?>

								</div>
							</div>
						</div>
						<?php endif; ?>




					</div>
				</div>
			</div>
		</div>
	</div><!-- container -->
</section><!-- myads-page -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_js'); ?>

<script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/users/my_ads.blade.php ENDPATH**/ ?>