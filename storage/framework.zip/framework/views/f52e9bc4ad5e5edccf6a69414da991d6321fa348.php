<?php $__env->startPush('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/forms/validation/form-validation.css')); ?>">
<link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<?php $__env->stopPush(); ?>
<?php
$city_combo = $data['city_combo'] ?? array();
$seller_type_combo = Config::get('static_arrays.seller_type') ?? array();


?>
<?php $__env->startSection('content'); ?>
<!-- myads-page -->
<section id="main" class="clearfix myads-page">
    <div class="container">
        <div class="breadcrumb-section">
            <!-- breadcrumb -->
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>Dashboard</li>
            </ol><!-- breadcrumb -->
        </div><!-- banner -->
        <div class="ads-info profile">
            <div class="row">
                <div class="col-md-4 text-center">
                    <!-- header -->
                    <?php echo $__env->make('users._user_dashboard_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- end header -->
                </div>
                <!-- recommended-cta-->
                <div class="col-md-8">
                    <div class="user-pro-section">
                        <div class="profile-details section">
                            <div class="row">
                                <div class="col-8">
                                    <h2>Profile Details</h2>
                                </div>
                                <div class="col-4">
                                    <div class="float-right">
                                        <a class="logoutbtn btn-sm btn-warning" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                                    </div>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </div>
                            <a class="edit show-form" href="javascript:void(0)"><i class="fa fa-pencil"></i>Edit</a>
                            <a class="edit show-profile d-none" href="#"><i class="fa fa-eye"></i>View</a>
                            <div class="view-profile">
                                <div class="form-group">
                                    <strong><label>Name</label></strong>
                                    : <?php echo e(Auth::user()->name); ?>

                                </div>
                                <div class="form-group">
                                    <strong><label>Email ID</label></strong>
                                    : <?php echo e(Auth::user()->email); ?>

                                </div>
                                <div class="form-group">
                                    <strong><label for="name-three">Mobile</label></strong>
                                    : <?php echo e(Auth::user()->mobile1); ?>

                                </div>
                                <div class="form-group">
                                    <strong><label>My City</label></strong>
                                    : <?php echo e(Auth::user()->city); ?>

                                </div>
                                <div class="form-group">
                                    <strong><label>I am a</label></strong>
                                    : <?php echo e(Auth::user()->seller_type); ?>

                                </div>
                                <div class="form-group">
                                    <strong><label>My Package</label></strong>
                                    : <?php echo e(Auth::user()->package->title ?? ''); ?>

                                </div>
                                <?php if(Auth::user()->package_id != '1'): ?>
                                <?php
                                $package = App\Payments::where('f_customer_pk_no',Auth::user()->id)->orderBy('pk_no','desc')->first();
                                ?>
                                <?php if($package): ?>
                                <div class="form-group">
                                    <strong><label>Package End Date</label></strong>
                                    : <?php echo e(date('d F, Y',strtotime($package->expired_on))); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                                <div class="form-group">
                                    <strong><label>Monthly Post Limit </label></strong>
                                    : <?php echo e(Auth::user()->package->ad_limit_in_montrh ?? ''); ?>

                                </div>
                            </div>
                            <div class="form d-none edit-profile">
                                <?php echo Form::open([ 'route' => 'my-profile-update', 'method' => 'post', 'class' => 'form-horizontal', 'files' => true , 'novalidate']); ?>

                                <div class="form-group">
                                    <strong><label>Profile Photo</label></strong>
                                    <div class="controls">
                                        <?php echo Form::file('profile', [ 'class' => 'form-control mb-1', 'data-validation-required-message' => 'This field is required', 'tabindex' => 1]); ?>

                                        <?php echo $errors->first('image', '<label class="help-block text-danger">:Profile Photo</label>'); ?>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <strong><label>Name</label></strong>
                                    <div class="controls">
                                        <?php echo Form::text('name', Auth::user()->name, [ 'class' => 'form-control mb-1', 'data-validation-required-message' => 'This field is required', 'placeholder' => 'Enter name', 'tabindex' => 1]); ?>

                                        <?php echo $errors->first('name', '<label class="help-block text-danger">:message</label>'); ?>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <strong><label>Email ID</label></strong>
                                    <div class="controls">
                                        <?php echo Form::text('email', Auth::user()->email, [ 'class' => 'form-control mb-1', 'data-validation-required-message' => 'This field is required', 'placeholder' => 'Enter email', 'tabindex' => 2]); ?>

                                        <?php echo $errors->first('email', '<label class="help-block text-danger">:message</label>'); ?>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <strong><label for="name-three">Mobile</label></strong>
                                    <div class="controls">
                                        <?php echo Form::number('mobile', Auth::user()->mobile1, [ 'class' => 'form-control mb-1', 'data-validation-required-message' => 'This field is required', 'placeholder' => 'Enter mobile number', 'tabindex' => 3]); ?>

                                        <?php echo $errors->first('mobile', '<label class="help-block text-danger">:message</label>'); ?>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <strong><label>Your City</label></strong>
                                    <div class="controls">
                                        <?php echo Form::select('city', $city_combo, Auth::user()->city, ['class'=>'form-control mb-1 ', 'id' => 'city', 'data-validation-required-message' => 'This field is required', 'placeholder' => 'Select city', 'tabindex' => 4 ]); ?>

                                        <?php echo $errors->first('city', '<label class="help-block text-danger">:message</label>'); ?>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <strong><label>You are a</label></strong>
                                    <?php echo Form::select('seller_type', $seller_type_combo, Auth::user()->seller_type, ['class'=>'form-control mb-1 ', 'id' => 'seller_type', 'data-validation-required-message' => 'This field is required', 'placeholder' => 'Select seller type', 'tabindex' => 4 ]); ?>

                                    <?php echo $errors->first('seller_type', '<label class="help-block text-danger">:message</label>'); ?>

                                </div>
                                <a style="margin-bottom: 9px;" href="<?php echo e(route('my-dashboard')); ?>" class="btn btn-info cancle">Cancle</a>
                                <button style="padding: 7px 29px 5px;" type="submit" class="btn btn-primary">Update Profile</button>
                                <?php echo Form::close(); ?>

                            </div>
                        </div>
                        <!-- change-password -->
                        <?php echo Form::open([ 'route' => 'my-password-update', 'method' => 'post', 'class' => 'form-horizontal', 'files' => true , 'novalidate']); ?>

                        <div class="change-password section">
                            <h2>Change password</h2>
                            <!-- form -->
                            <div class="form-group">
                                <label>Old Password</label>
                                <?php echo Form::password('old_password', [ 'class' => 'form-control mb-1', 'minlength' => '6', 'data-validation-required-message' => 'This field is required', 'data-validation-minlength-message' => 'Minimum 6 characters', 'placeholder' => 'Enter old password', 'tabindex' => 2, 'autocomplete' => 'off']); ?>

                                <?php echo $errors->first('old_password', '<label class="help-block text-danger">:message</label>'); ?>

                            </div>
                            <div class="form-group">
                                <label>New password</label>
                                <?php echo Form::password('password', [ 'class' => 'form-control mb-1', 'minlength' => '6', 'data-validation-required-message' => 'This field is required', 'data-validation-minlength-message' => 'Minimum 6 characters', 'placeholder' => 'Enter password', 'tabindex' => 2, 'autocomplete' => 'off']); ?>

                                <?php echo $errors->first('password', '<label class="help-block text-danger">:message</label>'); ?>

                            </div>
                            <div class="form-group">
                                <label>Confirm password</label>
                                <?php echo Form::password('password_confirmation', [ 'class' => 'form-control mb-1', 'minlength' => '6', 'data-validation-matches-match' => 'password', 'data-validation-matches-message' => 'Must match with password', 'data-validation-minlength-message' => 'Minimum 6 characters', 'data-validation-required-message' => 'This field is required', 'placeholder' => 'Enter confirm password', 'tabindex' => 4, 'autocomplete' => 'off']); ?>

                                <?php echo $errors->first('password_confirmation', '<label class="help-block text-danger">:message</label>'); ?>

                            </div>
                            <a style="margin-bottom: 9px;" href="<?php echo e(route('my-dashboard')); ?>" class="btn btn-info cancle">Cancle</a>
                            <button style="padding: 7px 29px 5px;" type="submit" class="btn btn-primary">Change Password</button>
                        </div>
                        <?php echo Form::close(); ?>

                        <!-- change-password -->
                        <!-- preferences-settings -->
                        <div class="preferences-settings section d-none">
                            <h2>Preferences Settings</h2>
                            <!-- checkbox -->
                            <div class="checkbox">
                                <label><input type="checkbox" name="logged"> Comments are enabled on my ads </label>
                                <label><input type="checkbox" name="receive"> I want to receive newsletter.</label>
                                <label><input type="checkbox" name="want">I want to receive advice on buying and selling. </label>
                            </div><!-- checkbox -->
                        </div><!-- preferences-settings -->
                    </div><!-- user-pro-edit -->
                </div><!-- profile -->
            </div><!-- row -->
        </div><!-- row -->
    </div><!-- container -->
</section><!-- myads-page -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom_js'); ?>
<script src="<?php echo e(asset('/assets/js/forms/validation/jqBootstrapValidation.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/forms/validation/form-validation.js')); ?>"></script>
<script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>

<script>
$(document).on('click', '.show-form', function() {
    $('.view-profile').addClass('d-none');
    $(this).hide();
    $('.edit-profile').removeClass('d-none');
    $('.show-profile').toggleClass('d-none');
});
$(document).on('click', '.show-profile', function() {
    $('.view-profile').removeClass('d-none');
    $(this).toggleClass('d-none');
    $('.edit-profile').addClass('d-none');
    $('.show-form').show();
});

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/users/my_dashboard.blade.php ENDPATH**/ ?>