<!DOCTYPE html>
    <html lang="<?php echo e(app()->getLocale() ?? 'en'); ?>">
        <!-- header_script -->
        <?php echo $__env->make('layouts.header_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('css'); ?>
        <!-- end header_script -->

        <body id="dalal_app">
        <!-- header -->
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header -->

        <!--###### <<<<<<<<  MAIN >>>>>>>> ######-->
        <main class="main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <!--###### <<<<<<<<  MAIN >>>>>>>> ######-->

        <!-- footer -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end footer -->

        <!-- common_modal -->
        <?php echo $__env->make('layouts.common_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end common_modal -->

        <!-- footer_script -->
        <?php echo $__env->make('layouts.footer_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end footer_script -->

        <!-- custom_script -->
        <?php echo $__env->yieldPushContent('custom_js'); ?>
        <!-- end custom_script -->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/layouts/app.blade.php ENDPATH**/ ?>