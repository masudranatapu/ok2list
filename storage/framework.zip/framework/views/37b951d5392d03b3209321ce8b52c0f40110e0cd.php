    <div class="section our-location">
        <div class="container">
            <div class="cities">
            <div class="section-title">
                <h1><?php echo app('translator')->get('web.best_rated_locations'); ?></h1>
            </div>
            <!-- row -->
            <div class="row">
                 <!-- Dhaka Division -->
                  <?php if($data['cities'] && count($data['cities']) > 0 ): ?>
                        <?php $__currentLoopData = $data['cities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($key > 7): ?>
                            <?php break; ?>
                        <?php endif; ?>
                <div class="col-6 col-md-4 col-lg-3 mb-4 text-center">
                    <a href="<?php echo e(route('ads.list', ['area' => $city->url_slug])); ?>" title="Ad post for <?php echo e($city->name); ?>">
                      <div class="location text-center">
                        <h3><?php echo e(number_format($city->total_post)); ?></h3>
                        <h4><i class="fa fa-map-marker"></i><?php echo e($city->name); ?></h4>
                    </div>
                    </a>
                </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div><!-- row -->
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/home/best_location.blade.php ENDPATH**/ ?>