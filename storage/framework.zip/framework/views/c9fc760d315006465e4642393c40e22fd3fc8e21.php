<?php $__env->startSection('content'); ?>
<section id="main" class="clearfix ad-details-page">
	<div class="container">
		<div class="breadcrumb-section">
			<ol class="breadcrumb">
				<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
				<li><?php echo app('translator')->get('web.promote_ad'); ?></li>
			</ol>
		</div>
		<?php if(isset($data['promote_your_ad_page1']) && ($data['promote_your_ad_page1']) != null ): ?>
			<div class="container">
				<div class="ads_banner text-center mb-4">
					<a href="<?php echo e($data['promote_your_ad_page1']->link); ?>" target="_blank" title="<?php echo e($data['promote_your_ad_page1']->name); ?>"><img src="<?php echo e(fileExit($data['promote_your_ad_page1']->photo)); ?>" class="w-100" alt="<?php echo e($data['promote_your_ad_page1']->name); ?>" style="height: 96px;"></a>
				</div>
			</div>
		<?php endif; ?>
			<div class="adpost-details privacy-policy">
				<div class="row">
					<div class="col-lg-8">
						<div class="section postdetails terms_info">
							<h4><?php echo app('translator')->get('web.promote_your_ad'); ?></h4>
							<div id="page-content" class="terms_info">
								<?php if($data['promote']): ?>
									<?php if(app()->getLocale() == 'en'): ?>
										<p><?php echo $data['promote']->description; ?></p>
									<?php else: ?>
										<p><?php echo $data['promote']->description_sl; ?></p>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="section quick-rules">
							<h4><?php echo app('translator')->get('web.quick_rules'); ?></h4>
							<p class="lead">Posting an ad on <a href="#">gogoads.lk</a> is free! However, all ads must follow our rules:</p>
							<ul>
								<li>Make sure you post in the correct category.</li>
								<li>Do not post the same ad more than once or repost an ad within 48 hours.</li>
								<li>Do not upload pictures with watermarks.</li>
								<li>Do not post ads containing multiple items unless it's a package deal.</li>
								<li>Do not put your email or phone numbers in the title or description.</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<?php if(isset($data['promote_your_ad_page2']) && ($data['promote_your_ad_page2']) != null ): ?>
				<div class="container">
					<div class="ads_banner text-center mb-4">
						<a href="<?php echo e($data['promote_your_ad_page2']->link); ?>" target="_blank" title="<?php echo e($data['promote_your_ad_page2']->name); ?>"><img src="<?php echo e(fileExit($data['promote_your_ad_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['promote_your_ad_page2']->name); ?>" style="height: 96px;"></a>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_footer_script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/common/promote_ad.blade.php ENDPATH**/ ?>