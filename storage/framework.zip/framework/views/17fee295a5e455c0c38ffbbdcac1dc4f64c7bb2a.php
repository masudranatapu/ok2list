    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('/app-assets/vendors/js/charts/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/app-assets/vendors/js/charts/raphael-min.js')); ?>"></script>
    <script src="<?php echo e(asset('/app-assets/vendors/js/charts/morris.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/app-assets/vendors/js/charts/jvector/jquery-jvectormap-2.0.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/app-assets/vendors/js/charts/jvector/jquery-jvectormap-world-mill.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/app-assets/vendors/js/charts/chartist.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/app-assets/vendors/js/charts/chartist-plugin-tooltip.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('/app-assets/js/scripts/pages/dashboard-ecommerce.js')); ?>"></script>
    <!-- END: Page Vendor JS-->


    <?php echo $__env->yieldPushContent('custom_js'); ?>
    
    
    <?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/layout/includes/home_js.blade.php ENDPATH**/ ?>