<?php
	$curent_route = request()->route()->getName();
?>
<div class="recommended-cta">
	<div class="cta">
		<div class="ad-profile section">
			<div class="user-profile">
				<div class="user">
					<?php if(!empty(Auth::user()->profile_pic_url)): ?>
						<img src="<?php echo e(asset(Auth::user()->profile_pic_url ?? '' )); ?>" class="rounded border mb-2" width="80" alt="avatar">
					<?php else: ?>
						<img src="<?php echo e(asset('assets/images/profile_img.jpg')); ?>" class="rounded border mb-2" width="80" alt="avatar">
					<?php endif; ?>
					<h2>Hello, <a href="#"><?php echo e(Auth::user()->name ?? ''); ?></a></h2>
					<h5><?php echo e(Auth::user()->email ?? ''); ?></h5>
					<hr>
				</div>
				<div class="favorites-user">
					<div class="my-ads">
						<a href="<?php echo e(route('my-ads')); ?>"><?php echo e(Auth::user()->total_post ?? 0); ?><small><?php echo app('translator')->get('web.my_ads'); ?></small></a>
					</div>
					<div class="favorites">
						<a href="<?php echo e(route('favorite-ads')); ?>"><?php echo e(Auth::user()->total_favorite ?? 0); ?><small><?php echo app('translator')->get('web.favorites'); ?></small></a>
					</div>
				</div>
			</div><!-- user-profile -->
			<?php
				$payments = App\Payments::where('f_customer_pk_no',Auth::user()->id)->where(['payment_type'=>'package'])->orderBy('pk_no','desc')->first();
			?>
			<ul class="user-menu">
				<li class="<?php echo e($curent_route == 'my-dashboard' ? 'active' : ''); ?> "><a href="<?php echo e(route('my-dashboard')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.my_account'); ?></a></li>
				<?php if(Auth::user()->is_verified==1): ?>
                    <li class="<?php echo e($curent_route == 'my-ads' ? 'active' : ''); ?>"><a href="<?php echo e(route('my-ads')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.my_ads'); ?></a></li>

                    <?php if(Auth::user()->package_id > 1): ?>
                    <li class="<?php echo e($curent_route == 'my-shop' ? 'active' : ''); ?>"><a href="<?php echo e(route('my-shop')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.my_shop'); ?></a></li>
                    <?php endif; ?>

                    <li class="<?php echo e($curent_route == 'favorite-ads' ? 'active' : ''); ?>"><a href="<?php echo e(route('favorite-ads')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.favorites'); ?></a></li>

                    <li class="<?php echo e($curent_route == 'promoted-ads' ? 'active' : ''); ?>"><a href="<?php echo e(route('promoted-ads')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.promotedads'); ?></a></li>
                    <li class="<?php echo e($curent_route == 'purchase-history' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('purchase-history')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.purchasehistory'); ?></a>
                    </li>
                    <li class="<?php echo e($curent_route == 'my-membership' ? 'active' : ''); ?>"><a href="<?php echo e(route('my-membership')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.membership'); ?></a></li>
                    <li class="<?php echo e($curent_route == 'chat' ? 'active' : ''); ?>"><a href="<?php echo e(route('chat')); ?>"><i class="fa fa-chevron-right"></i> <?php echo app('translator')->get('web.chat_messaging'); ?></a></li>
				<?php else: ?>
				    <h3 class="alert alert-danger pendinguser"><?php echo app('translator')->get('web.pending_massage'); ?></h3>
				<?php endif; ?>
			</li>
		</ul>
	</div>
	<!-- ad-profile -->
</div>
					</div><!-- cta -->
<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/users/_user_dashboard_menu.blade.php ENDPATH**/ ?>