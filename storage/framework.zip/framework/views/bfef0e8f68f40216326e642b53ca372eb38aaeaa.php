<?php $__env->startPush('custom_css'); ?>
<link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<style type="text/css">
    .footer-widget input[type="email"] {margin: 5px 0;font-weight: 300;font-size: 16px;}
    .urgent .featured-image{overflow: hidden;}
    .category-icon .img-fluid{width: 40px; height: 35px;}
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <section id="home-one-info" class="clearfix home-one">
        <?php echo $__env->make('home.top_slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <?php if(isset($data['home_page1']) && ($data['home_page1']) != null ): ?>
    <div class="container">
         <div class="ads_banner text-center mb-5">
             <a href="<?php echo e($data['home_page1']->link); ?>" target="_blank" title="<?php echo e($data['home_page1']->name); ?>"><img src="<?php echo e(fileExit($data['home_page1']->photo)); ?>" class="w-100" alt="<?php echo e($data['home_page1']->name); ?>" style="height: 96px;"></a>
         </div>
     </div>
     <?php endif; ?>


    <section id="home-two-info" class="clearfix home-two">
        <?php echo $__env->make('home.popular_category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <section id="home-three-info" class="clearfix home-three">
        <?php echo $__env->make('home.urgent_ads', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <?php if(isset($data['home_page2']) && ($data['home_page2']) != null ): ?>
    <div class="container">
         <div class="ads_banner text-center mb-5">
             <a href="<?php echo e($data['home_page2']->link); ?>" target="_blank" title="<?php echo e($data['home_page2']->name); ?>"><img src="<?php echo e(fileExit($data['home_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['home_page2']->name); ?>" style="height: 96px;"></a>
         </div>
     </div>
     <?php endif; ?>

    <section id="home-four-info" class="clearfix home-four">
        <?php echo $__env->make('home.best_location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>

    <?php if(isset($data['home_page3']) && ($data['home_page3']) != null ): ?>
    <div class="container">
         <div class="ads_banner text-center mb-5">
             <a href="<?php echo e($data['home_page3']->link); ?>" target="_blank" title="<?php echo e($data['home_page3']->name); ?>"><img src="<?php echo e(fileExit($data['home_page3']->photo)); ?>" class="w-100" alt="<?php echo e($data['home_page3']->name); ?>" style="height: 96px;"></a>
         </div>
     </div>
     <?php endif; ?>

    <section id="something-sell" class="clearfix parallax-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <h2 class="title"><?php echo app('translator')->get('web.something_to_sel'); ?></h2>
                    <h4><?php echo app('translator')->get('web.free_on_gogoads'); ?></h4>
                    <?php if(!empty(Auth::user()->id)): ?>
                        <?php
                            $payments = App\Payments::where('f_customer_pk_no',Auth::user()->id)->where(['payment_type'=>'package'])->orderBy('pk_no','desc')->first();
                        ?>
                        <?php if(isset($payments) && ($payments->status != "Due") ): ?>
                            <a href="#" data-toggle="modal" data-target="#staticBackdrop" class="btn btn-primary"><?php echo app('translator')->get('web.post_free_ad'); ?></a>
                        <?php else: ?>
                            <a href="javascript:;" class="btn btn-primary"><?php echo app('translator')->get('web.pending'); ?></a>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="#" data-toggle="modal" data-target="#staticBackdrop" class="btn btn-primary"><?php echo app('translator')->get('web.post_free_ad'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_js'); ?>
<script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>

<script src="<?php echo e(asset('/assets/js/imagelazy.js')); ?>"></script>
<script type="text/javascript">
    jQuery(function($) {
        $.imgLazy({ effect: 'fadeIn', viewport: true, timeout: 20 });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/home/home.blade.php ENDPATH**/ ?>