<?php
$area_query     		= $data['area_query'] ?? 'srilanka' ;
$get_area_query 		= $data['get_area_query'] ?? null ;
$get_category_query 	= $data['get_category_query'] ?? null ;

$urgent_ad 				= request()->get('urgent') ?? null;
$featured_ad 			= request()->get('featured') ?? null;
$top_ad 			    = request()->get('top') ?? null;

$new_ad 				= request()->get('new') ?? null;
$used_ad 				= request()->get('used') ?? null;
// $short_by 			= request()->get('sort') ?? null;

$sort_by 				= request()->get('sort') ?? 'date';
$order_by 				= request()->get('order') ?? 'desc';
$full_sort_by 			= $sort_by.'_'.$order_by;

// dd($data);
?>
<?php $__env->startPush('custom_css'); ?>
<style type="text/css">
	.short-dropdown a{line-height: 20px !important; font-size: 14px; padding: 5px 5px !important;}
	.short-dropdown a:hover{color: #149777;}
	.short-dropdown a.activ{color: #149777;}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
	<section id="main" class="clearfix category-page main-categories">
		<div class="container">
			<?php echo $__env->make('ads._topbar',$data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="category-info">
				<div class="row">
					<div class="aside_bar col-lg-4 col-md-4">
						<div class="category-accordion tr-accordion" id="accordion">
							<div class="card">
								<div class="card-header">
									<button data-toggle="collapse" data-target="#short_by" aria-expanded="true" aria-controls="short_by">Sort By</button>
								</div>
								<div id="short_by" class="collapse show" aria-labelledby="short_by" data-parent="#accordion">
									<div class="card-body">
										<select class="form-control" name="short_by" style="height: 34px;" id="short_by_select">
											<option value="date_desc" <?php echo e($full_sort_by == 'date_desc' ? 'selected' :''); ?>>Date : Newest on top</option>
											<option value="date_asc" <?php echo e($full_sort_by == 'date_asc' ? 'selected' :''); ?>>Date : Oldest on top</option>
											<option value="price_desc" <?php echo e($full_sort_by == 'price_desc' ? 'selected' :''); ?>>Price : High to low</option>
											<option value="price_asc" <?php echo e($full_sort_by == 'price_asc' ? 'selected' :''); ?>>Price : Low to high</option>
										</select>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="heading-4">
									<button data-toggle="collapse" data-target="#collapse-4" aria-expanded="true" aria-controls="collapse-4">Filter By</button>
								</div>
								<div id="collapse-4" class="collapse show" aria-labelledby="heading-4" data-parent="#accordion">
									<div class="card-body">
                                        <label for="top" class="<?php echo e($top_ad == 1 ? 'checked' : ''); ?>">
                                            <input type="checkbox" class="filter_by" name="top" id="top" value="top" <?php echo e($top_ad == 1 ? 'checked' : ''); ?>> Top </label>

										<label for="urgent" class="<?php echo e($urgent_ad == 1 ? 'checked' : ''); ?>">
											<input type="checkbox" class="filter_by" name="urgent" id="urgent" value="urgent" <?php echo e($urgent_ad == 1 ? 'checked' : ''); ?>> Urgent</label>
										<label for="featured" class="<?php echo e($featured_ad == 1 ? 'checked' : ''); ?>">
											<input type="checkbox" class="filter_by" name="featured" id="featured" value="featured" <?php echo e($featured_ad == 1 ? 'checked' : ''); ?>> Featured</label>
										<label for="new" class="<?php echo e($new_ad == 1 ? 'checked' : ''); ?>">
											<input type="checkbox" class="filter_by" name="new" id="new" value="new" <?php echo e($new_ad == 1 ? 'checked' : ''); ?>> New</label>
										<label for="used" class="<?php echo e($used_ad == 1 ? 'checked' : ''); ?>">
											<input type="checkbox" class="filter_by" name="used" id="used" value="used" <?php echo e($used_ad == 1 ? 'checked' : ''); ?>> Used</label>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="heading-1">
									<button data-toggle="collapse" data-target="#collapse-1" aria-expanded="true" aria-controls="collapse-1">All Categories</button>
								</div>
								<div id="collapse-1" class="collapse show" aria-labelledby="heading-1" data-parent="#accordion">
									<div class="card-body ">
										<ul>
											<?php if(isset($data['category']) && count($data['category']) > 0): ?>
												<?php $__currentLoopData = $data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<a href="<?php echo e(route('ads.list', ['area' => $get_area_query, 'category' => $cat->url_slug ])); ?>"><img src="<?php echo e($cat->icon_src); ?>" alt="" width="16" height="16"> <?php echo e($cat->name); ?><span>(<?php echo e($cat->total_post); ?>)</span></a>
														<a data-toggle="collapse" href="#lf_<?php echo e($cat->url_slug); ?>" role="button" aria-expanded="false" class="float-right" aria-controls="lf_<?php echo e($cat->url_slug); ?>"><i class="fa fa-chevron-down"></i></a>
														<div class="collapse hide" id="lf_<?php echo e($cat->url_slug); ?>">
															<div class="card">
																<ul class="subdropdowncss">
																	<?php if(isset($data['subcategory']) && count($data['subcategory']) > 0): ?>
																		<?php $__currentLoopData = $data['subcategory']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																			<?php if($cat->pk_no == $scat->parent_id): ?>
																				<li><a href="<?php echo e(route('ads.list', ['area' => $get_area_query, 'category' => $scat->url_slug ])); ?>"><i class="fa fa-chevron-right"></i> <?php echo e($scat->name); ?> (<?php echo e($scat->total_post); ?>)</a></li>
																			<?php endif; ?>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	<?php endif; ?>
																</ul>
															</div>
														</div>
													</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</ul>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="heading-1">
									<button class="collapsed" data-toggle="collapse" data-target="#location" aria-expanded="true" aria-controls="collapse-1">Locations</button>
								</div>
								<div id="location" class="collapse" aria-labelledby="heading-1" data-parent="#accordion">
									<div class="card-body">
										<ul>
											<?php if(isset($data['divisions']) && count($data['divisions']) > 0 ): ?>
												<?php $__currentLoopData = $data['divisions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $divi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<a href="<?php echo e(route('ads.list', ['area' => $divi->url_slug, 'category' => $get_category_query ])); ?>"><?php echo e($divi->name); ?><span>( <?php echo e($divi->total_post); ?> )</span></a>
														<a data-toggle="collapse" href="#lf<?php echo e($divi->url_slug); ?>" role="button" aria-expanded="false" class="float-right" aria-controls="lf<?php echo e($divi->url_slug); ?>"><i class="fa fa-chevron-down"></i></a>
														<div class="collapse" id="lf<?php echo e($divi->url_slug); ?>">
															<div class="card">
																<ul class="subdropdowncss">
																	<?php if(isset($data['areas']) && count($data['areas']) > 0 ): ?>
																		<?php $__currentLoopData = $data['areas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ak => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																			<?php if($area->division_pk_no == $divi->pk_no): ?>
																				<li><a href="<?php echo e(route('ads.list', ['area' => $area->url_slug, 'category' => $get_category_query ])); ?>"><i class="fa fa-chevron-right"></i> <?php echo e($area->name); ?> (<?php echo e($area->total_post); ?>)</a></li>
																			<?php endif; ?>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	<?php endif; ?>
																</ul>
															</div>
														</div>
													</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</ul>
									</div>
								</div>
							</div>
                            <?php if(isset($data['list_page2']) && ($data['list_page2']) != null ): ?>
								<div class="card">
									<div class="card-body">
										<div class="ads_banner text-center">
											<a href="<?php echo e($data['list_page2']->link); ?>" target="_blank" title="<?php echo e($data['list_page2']->name); ?>"><img src="<?php echo e(fileExit($data['list_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['list_page2']->name); ?>" style="height: 600px;"></a>
										</div>
									</div>
								</div>
                            <?php endif; ?>
						</div>
					</div>
					<div class="col-md-8 col-lg-8">
						<div class="section recommended-ads">
							<div class="featured-top">
								<h4>Recommended Ads for You</h4>
							</div>
							<?php if(isset($data['rows']) && count($data['rows']) > 0): ?>
								<?php $__currentLoopData = $data['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $row = ( object ) $row; ?>
									<div class="ad-item verified_ads row <?php echo e($row->promotion == 'Top' ? 'topad' : 'notop'); ?> ">
										<div class="item-image-box col-lg-4">
											<div class="item-image">
												<a href="<?php echo e(route('ad.details',['pk_no' => $row->pk_no,'url_slug' => $row->url_slug])); ?>" title="<?php echo e($row->ad_title); ?>">
													<img src="<?php echo e(asset('assets/images/default-load.png')); ?>"  data-src="<?php echo e(asset($row->img_path_thumb)); ?>" alt="<?php echo e($row->ad_title); ?>" class="img-fluid">
													<?php if($row->promotion_to>=Carbon\Carbon::today()): ?>
														<?php if($row->promotion == 'Feature'): ?>
															<span class="featured-ad">Featured</span>
														<?php endif; ?>
														<?php if($row->promotion == 'Urgent'): ?>
															<span class="featured-ad">Urgent</span>
														<?php endif; ?>
													<?php endif; ?>
												</a>
											</div>
										</div>
										<div class="item-info col-lg-8">
											<div class="ad-info">
												
												<h3 class="item-price">Rs <?php echo e(number_format($row->price)); ?>

													<?php if($row->promotion == 'Top'): ?> <span class="topadtag"><?php echo e($row->promotion); ?></span> <?php endif; ?>
													<div class="float-right">
														<?php if($row->is_like == '1'): ?>
															<a href="<?php echo e(route('ad-post-dislike', $row->pk_no)); ?>" class="like_ads btn-sm" title="Like"><i class="fa fa-thumbs-up"></i>
																<?php echo e($row->like_count ?? '0'); ?>

															</a>
														<?php else: ?>
															<a href="<?php echo e(route('ad-post-like', $row->pk_no)); ?>" class="like_ads btn-sm" title="Like"><i class="fa fa-thumbs-up"></i>
																<?php echo e($row->like_count ?? '0'); ?>

															</a>
														<?php endif; ?>
													</div>
												</h3>
												<h4 class="item-title">
													<a href="<?php echo e(route('ad.details',['pk_no' => $row->pk_no,'url_slug' => $row->url_slug])); ?>"><?php echo e($row->ad_title); ?></a>

												</h4>
												<div class="item-cat">
													<span><a href="javascript:void(0)"><?php echo e($row->category->name ?? ''); ?></a></span> /
													<span><a href="javascript:void(0)"><?php echo e($row->subcategory->name ?? ''); ?></a>&nbsp;&nbsp; </span>
													
												</div>
												<?php
													$payment = App\Payments::where('f_customer_pk_no',$row->customer_pk_no)->where('status','VALID')->orderBy('pk_no','desc')->first();
												?>
												<?php if($payment): ?>
													<div class="premier_ads">
														<span class="member">
															<i class="fa fa-star"></i>
															Member
														</span>
														<span class="verified">
															<i class="fa fa-check"></i>
															Verified Seller
														</span>
													</div>
												<?php endif; ?>
											</div>
											<div class="ad-meta">
												<div class="meta-content">
													<span class="dated"><?php echo e(date('d M, Y H:i A',strtotime($row->created_at))); ?></span>
													<?php if($row->using_condition): ?>
														<a href="javascript:void(0)" class="tag">
															<i class="fa fa-tags"></i>
															<?php echo e($row->using_condition); ?>

														</a>
													<?php endif; ?>
												</div>
												<div class="user-option pull-right">
													<a href="#" data-toggle="tooltip" data-placement="top" title="<?php echo e($row->area->name ?? ''); ?>, <?php echo e($row->area->city->name ?? ''); ?> <?php echo e($row->area->division->name ?? ''); ?>"><i class="fa fa-map-marker"></i> </a>
														<!-- <a class="online" href="#" data-toggle="tooltip" data-placement="top" title="<?php echo e($row->user->seller_type ?? ''); ?>"><i class="fa fa-user"></i> </a> -->
													</div>
												</div>
											</div>
										</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								<p class="text-center mt-2">Product not available</p>
							<?php endif; ?>

							<?php if(isset($data['rows']) && count($data['rows']) > 0): ?>
								<div class="text-center">
									<ul class="pagination">
										<?php if(request()->get('page') < 2 ): ?>
											<li class="page-item">
												<a class="page-link" href="<?php echo e(request()->fullUrl()); ?>" style="background-color: #ccc;"  id="pagePrev">
													« Previous
												</a>
											</li>
										<?php else: ?>
											<li class="page-item">
												<a class="page-link" href="<?php echo e(request()->fullUrl()); ?>" id="pagePrev">
													« Previous
												</a>
											</li>
										<?php endif; ?>

										<?php if($data['page_count'] == request()->get('page')): ?>
											<li class="page-item">
												<a class="page-link" href="<?php echo e(request()->fullUrl()); ?>" style="background-color: #ccc;" id="pageNext">
													Next »
												</a>
											</li>
										<?php else: ?>
											<li class="page-item">
												<a class="page-link" href="<?php echo e(request()->fullUrl()); ?>" id="pageNext">
													Next »
												</a>
											</li>
										<?php endif; ?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
            <?php if(isset($data['list_page3']) && ($data['list_page3']) != null ): ?>
				<div class="container">
					<div class="ads_banner text-center mb-5">
						<a href="<?php echo e($data['list_page3']->link); ?>" target="_blank" title="<?php echo e($data['list_page3']->name); ?>"><img src="<?php echo e(fileExit($data['list_page3']->photo)); ?>" class="w-100" alt="<?php echo e($data['list_page3']->name); ?>" style="height: 96px;"></a>
					</div>
				</div>
             <?php endif; ?>
		</div>
	</section>

	<section id="something-sell" class="clearfix parallax-section">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 text-center">
					<h2 class="title">Do you have something-sell?</h2>
					<h4>Post your ad for free on gogoads.lk</h4>
					<a href="#" data-toggle="modal" data-target="#staticBackdrop" class="btn btn-primary">Post Your Ad</a>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_js'); ?>
    <script type="text/javascript">
    	$(document).ready(function(e){
    		var currentPage = Number(`<?php echo e($data['current_page']); ?>`);
    		var page_count = Number(`<?php echo e($data['page_count']); ?>`);

    		if (currentPage > 1 ) {
    			var prev_page = currentPage - 1 ;
    		}else{
    			var prev_page = 1 ;
    		}


    		var next_page = currentPage + 1 ;

    		var pagePrev = $('#pagePrev').attr('href');
    		var pageNext = $('#pageNext').attr('href');
    		var prev_url = makeUrl(pagePrev, 'page' , prev_page);
    		if(currentPage == 1){
    			$('#pagePrev').attr('href','javascript:void(0)');
    		}else{
    			$('#pagePrev').attr('href',prev_url);
    		}


    		var next_url = makeUrl(pageNext, 'page' , next_page);
    		if(currentPage != page_count){
    			$('#pageNext').attr('href',next_url);
    		}else{
    			$('#pageNext').attr('href','javascript:void(0)');
    		}




    	})

    	$(document).on('click', '#key_search', function(e){

    		var keywords = $('#keywords').val();

    		var new_url = old_url = $(location).attr("href");
    		new_url = makeUrl(new_url, 'keywords' , keywords);

    		window.location.href = new_url;

    	})

    	$(document).on('change', '#short_by_select', function(e){
    		var short_by 	= $(this).val();
    		var new_url 	= old_url = $(location).attr("href");
    		var param 		= $(this).val();
    		var arr 			= param.split('_');
    		var order 		= arr[0];
    		var sort 			= arr[1];
    		var val 			= 0;
    		new_url = makeUrl(old_url, 'sort' , order);
    		new_url = makeUrl(new_url, 'order' , sort);
    		window.location.href = new_url;
    	})
    	$(document).on('click','.filter_by',function(e){
    		var new_url = old_url = $(location).attr("href");
    		var param 	= $(this).val();
    		var val 		= 0;

    		if($(this).is(":checked")){
    			var val = 1;
    			var new_url = makeUrl(old_url, param, val);
    		}	else{
    			var val = 0;
    			var new_url = makeUrl(old_url, param, val);
   			}
   			new_url = makeUrl(new_url, 'page' , 1);
    		window.location.href = new_url;


    	})

    	function makeUrl(old_url,param,val)
    	{
    		var url 					= new URL(old_url);
    		var search_params = url.searchParams;
    		search_params.set(param, val);
    		url.search 				= search_params.toString();
    		return url.toString();
    	}

	  	$(document).on('click', '.fa-chevron-down', function(){
       		$(this).addClass("fa-chevron-up");
       		$(this).removeClass("fa-chevron-down");
	  	});
	  	$(document).on('click', '.fa-chevron-up', function(){
       		$(this).addClass("fa-chevron-down");
       		$(this).removeClass("fa-chevron-up");
	  	});
    </script>
    <script src="<?php echo e(asset('/assets/js/imagelazy.js')); ?>"></script>
    <script type="text/javascript">
		jQuery(function($) {
			$.imgLazy({ effect: 'fadeIn', viewport: true, timeout: 20 });
		});
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/ads/list.blade.php ENDPATH**/ ?>