<?php $__env->startSection('product_list','active'); ?>
<?php $__env->startSection('Product Management','open'); ?>

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('product.product_view'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page-name'); ?> <?php echo app('translator')->get('product.product_view'); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo app('translator')->get('product.breadcrumb_title'); ?>  </a></li>
<li class="breadcrumb-item active"><?php echo app('translator')->get('product.breadcrumb_sub_title'); ?>    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_css'); ?>
<style type="text/css">
    #scrollable-dropdown-menu .tt-menu {
      max-height: 260px;
      overflow-y: auto;
      width: 100%;
      border: 1px solid #333;
      border-radius: 5px;

  }
  #scrollable-dropdown-menu2 .tt-menu {
      max-height: 260px;
      overflow-y: auto;
      width: 100%;
      border: 1px solid #333;
      border-radius: 5px;

  }
  .twitter-typeahead{
    display: block !important;
    /*width: 90%;*/
}


</style>

<?php $__env->stopPush(); ?>


<?php


$roles  = userRolePermissionArray();
$type   = request('type') ?? null;
$row    = $data['row'] ;

// echo "<pre>";
// print_r($row->allPhotos);
// die();

?>

<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="row">
        <div class="col-md-12">
            <div class="card" >
                <div class="card-content">
                    <div class="card-body">
                        

                        <?php echo Form::open([ 'route' => ['admin.product.update', $row->pk_no], 'method' => 'post', 'class' => 'form-horizontal', 'files' => true ]); ?>

                        <div class="row form-group">
                            <label class="col-sm-3">URL Slug</label>
                            <div class="col-sm-9 user-type">
                                    <input type="search" value="<?php echo e($row->url_slug); ?>" name="url_slug" id="key_search" class="form-control search-input2 noSpace" autocomplete="off" data-validation-required-message ="This field is required"  />

                            </div>
                        </div>
                        <div class="row form-group">
                            <label class="col-sm-3">Promotion Type</label>
                            <div class="col-sm-9 user-type">
                                <select class="form-control" name="promotion" disabled>
                                    <option value="" selected="">--select--</option>
                                    <option value="Top" <?php echo e($row->promotion == 'Top' ? 'selected' : ''); ?>>Top</option>
                                    <option value="Feature" <?php echo e($row->promotion == 'Feature' ? 'selected' : ''); ?>>Feature</option>
                                    <option  value="Urgent" <?php echo e($row->promotion == 'Urgent' ? 'selected' : ''); ?>>Urgent</option>
                                    <option value="Basic" <?php echo e($row->promotion == 'Basic' ? 'selected' : ''); ?>>Free</option>
                                </select>
                            </div>
                        </div>

                        <div class="row form-group">
                            <label class="col-sm-3">Post For</label>
                            <div class="col-sm-9 user-type">
                             <?php echo e($row->main_category); ?>

                         </div>
                     </div>
                     <div class="row form-group">
                        <label class="col-sm-3">Type of ad</label>
                        <div class="col-sm-9 user-type">
                            <?php echo e($row->ad_type); ?>

                        </div>
                    </div>

                    <div class="row form-group add-title">
                        <label class="col-sm-3 label-title">Ad Title</label>
                        <div class="col-sm-9">
                            <input type="text" readonly="" class="form-control" id="text" value="<?php echo e($row->ad_title); ?>">
                        </div>
                    </div>
                    
                    <div class="row form-group add-title">
                        <label class="col-sm-3 label-title">City/Division</label>
                        <div class="col-sm-9">
                            <input type="text" readonly="" class="form-control" id="text" value="<?php echo e($row->area->city->name ?? $row->area->division->name); ?>">
                        </div>
                    </div>
                    <div class="row form-group add-title">
                        <label class="col-sm-3 label-title">Area</label>
                        <div class="col-sm-9">
                            <input type="text" readonly="" class="form-control" id="text" value="<?php echo e($row->area->name ?? ''); ?>">
                        </div>
                    </div>
                    <div class="row form-group add-image">
                        <label class="col-sm-3 label-title">Ad Photos</label>
                        <div class="col-sm-9 adsimgview">
                            <div class="upload-section">
                                <?php if(($row->allPhotos) && count($row->allPhotos) > 0 ): ?>
                                <?php $__currentLoopData = $row->allPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="" target="_blank"><img class="img-thumbnail example-image" src="<?php echo e(asset('uploads/product/'.$row->pk_no.'/'.$img->img_name)); ?>" alt="" width="200" /></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row form-group select-condition">
                        <label class="col-sm-3">Condition</label>
                        <div class="col-sm-9">
                            <?php echo e($row->using_condition); ?>

                        </div>
                    </div>
                    <div class="row form-group select-price">
                        <label class="col-sm-3 label-title">Price(Rs)</label>
                        <div class="col-sm-9">

                            <input type="text" readonly="" value="<?php echo e($row->price); ?>" class="form-control" id="text1">
                            <div class="checkbox mt-2">
                                <input type="radio" name="price" value="negotiable" id="negotiable" <?php echo e($row->negotiable == 1 ? 'checked' : ''); ?>>
                                <label for="negotiable">Negotiable </label>
                            </div>
                        </div>
                    </div>
                    <div class="row form-group brand-name">
                        <label class="col-sm-3 label-title">Category</label>
                        <div class="col-sm-9">
                            <input type="text" readonly="" class="form-control" value="<?php echo e($row->category->name); ?>">
                        </div>
                    </div>
                    <div class="row form-group brand-name">
                        <label class="col-sm-3 label-title">Subcategory</label>
                        <div class="col-sm-9">
                            <input type="text" readonly="" class="form-control" value="<?php echo e($row->subcategory->name); ?>">
                        </div>
                    </div>
                    <div class="row form-group brand-name">
                        <label class="col-sm-3 label-title">Brand Name</label>
                        <div class="col-sm-9">
                            <input type="text" readonly="" class="form-control" value="<?php echo e($row->brand_name); ?>">
                        </div>
                    </div>
                    <div class="row form-group model-name">
                        <label class="col-sm-3 label-title">Model</label>
                        <div class="col-sm-9">
                            <input type="text" readonly="" class="form-control" id="model" value="<?php echo e($row->model_name); ?>">
                        </div>
                    </div>
                    <div class="row form-group additional">
                        <label class="col-sm-3 label-title">Additional</label>
                        <div class="col-sm-9">
                            <?php echo e($row->prod_feature); ?>

                        </div>
                    </div>
                    <div class="row form-group item-description">
                        <label class="col-sm-3 label-title">Description</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="textarea" readonly="" rows="8"><?php echo e($row->description); ?></textarea>
                        </div>
                    </div>
                    <div class="row form-group brand-name">
                        <label class="col-sm-3 label-title">Date & Time</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" value="<?php echo e(date('d M, Y : h :i A', strtotime($row->created_at))); ?>">
                        </div>
                    </div>
                    <div class="section seller-info">
                        <h4>Seller Information</h4>
                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Seller Type</label>
                            <div class="col-sm-9">
                                <?php echo e($row->customer->seller_type ?? ''); ?>

                            </div>
                        </div>
                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Your Name</label>
                            <div class="col-sm-9">
                                <input type="text" readonly="" name="name" class="form-control" value="<?php echo e($row->customer->name ?? ''); ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Your Email ID</label>
                            <div class="col-sm-9">
                                <input type="email" readonly="" name="email" class="form-control" value="<?php echo e($row->customer->email ?? ''); ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Mobile Number (1)</label>
                            <div class="col-sm-9">
                                <input type="text" readonly="" name="mobileNumber" class="form-control" value="<?php echo e($row->customer->mobile1 ?? ''); ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Mobile Number (2)</label>
                            <div class="col-sm-9">
                                <input type="text" readonly="" name="mobileNumber" class="form-control" value="<?php echo e($row->customer->mobile2 ?? ''); ?>">
                            </div>
                        </div>
                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Address</label>
                            <div class="col-sm-9">
                                <input type="text" readonly="" name="address" class="form-control" value="<?php echo e($row->address ?? ''); ?>">
                            </div>
                        </div>

                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Is Rejected </label>
                            <div class="col-sm-9">
                               <select class="form-control" name="is_delete">
                                   <option value="0" <?php echo e($row->is_delete == 0 ? 'selected' : ''); ?> >No</option>
                                   <option value="1" <?php echo e($row->is_delete == 1 ? 'selected' : ''); ?>>Yes</option>
                               </select>
                            </div>
                        </div>

                        <div class="row form-group">
                            <label class="col-sm-3 label-title">Status</label>
                            <div class="col-sm-9">
                               <select class="form-control" name="is_active">
                                   <option value="0" <?php echo e($row->is_active == 0 ? 'selected' : ''); ?>>Pending</option>
                                   <option value="1" <?php echo e($row->is_active == 1 ? 'selected' : ''); ?>>Active</option>
                                   <option value="2" <?php echo e($row->is_active == 2 ? 'selected' : ''); ?>>Expired</option>
                                   <option value="3" <?php echo e($row->is_active == 3 ? 'selected' : ''); ?>>Draft</option>
                               </select>
                            </div>
                        </div>

                        <div class="row form-group rejected_reason">
                            <label class="col-sm-3 label-title">Reason of Reject (If Reject)</label>
                            <div class="col-sm-9">
                                <textarea class="form-control rejected_reason" placeholder="why you will reject this ad ??" rows="8" name="rejected_reason"><?php echo e($row->comments ?? ''); ?></textarea>

                            </div>
                        </div>





                        <div class="row form-group action_div">
                            <label class="col-sm-3 label-title"></label>
                            <div class="col-sm-9">
                                
                                <button type="submit" value="" class="btn btn-danger">Update</button>
                            </div>
                        </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!--/ Recent Transactions -->

<?php $__env->stopSection(); ?>
<!--push from page-->
<?php $__env->startPush('custom_js'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.11.1/typeahead.bundle.min.js"></script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script type="text/javascript">
    $('.noSpace').keyup(function() {
     this.value = this.value.replace(/\s/g,'');
    });


    $(document).on('click', '.rejectad', function(){

        $('.rejected_reason').removeClass('d-none');
        $('.action_div').toggleClass('d-none');
    });

    jQuery(document).ready(function($) {
        typeahead('customer');
    });

    function typeahead(type) {
        var get_url = $('#base_url').val();
        var engine = new Bloodhound({
            remote: {
                url: get_url+'/product/get-url-slug?q=%QUERY%&type='+type,
                wildcard: '%QUERY%',
                cache: false,
            },
            datumTokenizer: Bloodhound.tokenizers.whitespace('q'),
            queryTokenizer: Bloodhound.tokenizers.whitespace
        });

        $(".search-input2").typeahead({
            hint: true,
            highlight: true,
            minLength: 1,
        }, {
            source: engine.ttAdapter(),
            // This will be appended to "tt-dataset-" to form the class name of the suggestion menu.
            // display: 'NAME',
            // displayKey: 'IG_CODE',
            name: 'url_slug',
            displayKey: 'url_slug',
            // valueKey: 'IG_CODE',
            limit: 20,

            // the key from the array we want to display (name,id,email,etc...)
            templates: {
                empty: [
                '<div class="list-group search-results-dropdown"><div class="list-group-item">Nothing found.</div></div>'
                ],
                header: [
                '<div class="list-group search-results-dropdown">'
                ],
                suggestion: function (data) {
                    return '<span class="list-group-item" style="cursor: pointer;">' + data.url_slug + '</span>'
                }
            }
        });
    }
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>