<?php
	$selected_area  = $data['area_query_display'] == null ? 'srilanka' : $data['area_query_display'] ;
?>
<div class="breadcrumb-section">
	<ol class="breadcrumb">
		<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
		<li><a href="<?php echo e(route('ads.list')); ?>">All Ads</a></li>
		<?php if(isset($data['category_name']) && ($data['category_name'] != null)): ?>
			<li><?php echo e($data['category_name']); ?></li>
		<?php endif; ?>
		<?php if(isset($data['get_area_query']) && ($data['get_area_query'] != null)): ?>
			<li><?php echo e($data['get_area_query']); ?></li>
		<?php endif; ?>
	</ol>
</div>

<?php if(isset($data['detail_page1']) && ($data['detail_page1']) != null ): ?>
	<div class="container">
		<div class="ads_banner text-center mb-5">
			<a href="<?php echo e($data['list_page1']->link); ?>" target="_blank" title="<?php echo e($data['list_page1']->name); ?>"><img src="<?php echo e(fileExit($data['list_page1']->photo)); ?>" class="w-100" alt="<?php echo e($data['list_page1']->name); ?>" style="height: 96px;"></a>
		</div>
	</div>
 <?php endif; ?>

 <?php if(isset($data['list_page1']) && ($data['list_page1']) != null ): ?>
	<div class="ads_banner text-center mb-4">
		<a href="<?php echo e($data['list_page1']->link); ?>" target="_blank" title="<?php echo e($data['list_page1']->name); ?>"><img src="<?php echo e(fileExit($data['list_page1']->photo)); ?>" class="w-100" alt="<?php echo e($data['list_page1']->name); ?>" style="height: 96px;"></a>
	</div>
<?php endif; ?>

<div class="banner">
	<div class="banner-form banner-form-full">
		<form onsubmit="event.preventDefault()">
			<i class="fa fa-map-marker"></i>
			<div class="dropdown category-dropdown select-category" data-toggle="modal" data-target="#divisioncitymodal">
				<span><?php echo e($selected_area); ?></span>
			</div>
			<i class="fa fa-tag"></i>
			<div class="dropdown category-dropdown select-category" data-toggle="modal" data-target="#exampleModal">
				<span><?php echo e($data['category_query_display'] ?? 'Select Category'); ?></span>
			</div>
			<input type="text" class="form-control banner_search" placeholder="Type Your key word" id="keywords" value="<?php echo e(request()->get('keywords')); ?>">
			<button type="button" class="form-control" value="Search" id="key_search">Search</button>
		</form>
	</div>
</div><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/ads/_topbar.blade.php ENDPATH**/ ?>