<?php $__env->startSection('content'); ?>
<section id="main" class="clearfix about-us page">
	<div class="container">
        <style>
            .about-us-images{
                width: 100%;
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
            }
        </style>
		<div class="breadcrumb-section">
			<ol class="breadcrumb">
				<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
				<li><?php echo app('translator')->get('web.about_us'); ?></li>
			</ol>
		</div>
        <?php if(isset($data['about_us_page1']) && ($data['about_us_page1']) != null ): ?>
			<div class="container">
				<div class="ads_banner text-center mb-4">
					<a href="<?php echo e($data['about_us_page1']->link); ?>" target="_blank" title="<?php echo e($data['about_us_page1']->name); ?>"><img src="<?php echo e(fileExit($data['about_us_page1']->photo)); ?>" class="w-100" alt="<?php echo e($data['about_us_page1']->name); ?>" style="height: 96px;"></a>
				</div>
			</div>
         <?php endif; ?>
		<div class="section about">
			<div class="about-info">
				<div class="row">
					<div class="col-lg-6">
						<div class="about-us-images">
                            <span class="helper"></span>
							<?php if($data['about']): ?>
								<img src="<?php if($data['about']->image): ?> <?php echo e(asset($data['about']->image)); ?> <?php else: ?> <?php echo e(asset('assets/images/about-us/about.jpg')); ?> <?php endif; ?>" alt="About us Image" class="img">
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="about-text">
							<h3><?php echo app('translator')->get('web.about_us'); ?> <?php echo app('translator')->get('web.gogoads_title'); ?></h3>
							<div class="description-paragraph">
								<?php if($data['about']): ?>
									<?php if(app()->getLocale() == 'en'): ?>
										<p><?php echo $data['about']->details_en; ?></p>
									<?php else: ?>
										<p><?php echo $data['about']->details_sl; ?></p>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="approach">
				<div class="row">
					<div class="col-md-4 text-center">
						<div class="our-approach">
							<h3><?php echo app('translator')->get('web.mission'); ?></h3>
							<?php if($data['about']): ?>
								<?php if(app()->getLocale() == 'en'): ?>
									<p><?php echo $data['about']->mission_en; ?></p>
								<?php else: ?>
									<p><?php echo $data['about']->mission_sl; ?></p>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-md-4 text-center">
						<div class="our-approach">
							<h3><?php echo app('translator')->get('web.vision'); ?></h3>
							<?php if($data['about']): ?>
								<?php if(app()->getLocale() == 'en'): ?>
									<p><?php echo $data['about']->vision_en; ?></p>
								<?php else: ?>
									<p><?php echo $data['about']->vision_sl; ?></p>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-md-4 text-center">
						<div class="our-approach">
							<h3><?php echo app('translator')->get('web.our_values'); ?></h3>
							<?php if($data['about']): ?>
								<?php if(app()->getLocale() == 'en'): ?>
									<p><?php echo $data['about']->our_values_en; ?></p>
								<?php else: ?>
									<p><?php echo $data['about']->our_values_sl; ?></p>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
        <?php if(isset($data['about_us_page2']) && ($data['about_us_page2']) != null ): ?>
			<div class="container">
				<div class="ads_banner text-center mb-4">
					<a href="<?php echo e($data['about_us_page2']->link); ?>" target="_blank" title="<?php echo e($data['about_us_page2']->name); ?>"><img src="<?php echo e(fileExit($data['about_us_page2']->photo)); ?>" class="w-100" alt="<?php echo e($data['about_us_page2']->name); ?>" style="height: 96px;"></a>
				</div>
			</div>
         <?php endif; ?>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_footer_script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/common/about_us.blade.php ENDPATH**/ ?>