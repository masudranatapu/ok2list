<?php $__env->startSection('Web Setting','open'); ?>
<?php $__env->startSection('faq','active'); ?>

<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('web_setting.faq_title'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page-name'); ?> <?php echo app('translator')->get('web_setting.faq_title'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#"><?php echo app('translator')->get('admin_role.breadcrumb_title'); ?>  </a></li>
<li class="breadcrumb-item active"><?php echo app('translator')->get('web_setting.faq_title'); ?>    </li>
<?php $__env->stopSection(); ?>

<!--push from page-->
<?php $__env->startPush('custom_css'); ?>
<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<?php $__env->stopPush(); ?>

<?php
$roles = userRolePermissionArray();
$rows  = $data['data'];
?>

<?php $__env->startSection('content'); ?>

<div class="content-body">
    <section id="pagination">
        <div class="row">
            <div class="col-md-12">
                    <div class="card card-sm">
                        <div class="card-header">
                            <?php if(hasAccessAbility('new_faq', $roles)): ?>
                            <a class="btn btn-round btn-sm btn-primary text-white" href="<?php echo e(route('admin.faq.create')); ?>" title="ADD NEW PACKAGE"><i class="ft-plus text-white"></i>Add Faq</a>
                            <?php endif; ?>

                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                <ul class="list-inline mb-0">
                                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-content collapse show">
                            <div class="card-body card-dashboard">
                                <div class="table-responsive ">
                                    <table class="table table-striped table-bordered alt-pagination table-sm" id="indextable">
                                        <thead>
                                        <tr>
                                            <th class="text-center">SL</th>
                                            <th class="text-center">Question</th>
                                            <th>Answer</th>
                                            <th style="width: 120px;"><?php echo app('translator')->get('package.action'); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <tr>
                                                <td><?php echo e($loop->index + 1); ?></td>
                                                <td><?php echo e($row->question); ?></td>
                                                <td><?php echo e($row->answer); ?></td>
                                                <td>
                                                    <?php if(hasAccessAbility('view_faq', $roles)): ?>
                                                    <a href="<?php echo e(route('admin.faq.view',[$row->pk_no])); ?>" class="btn btn-xs btn-outline-primary mr-1" title="VIEW"><i class="la la-eye"></i></a>
                                                    <?php endif; ?>

                                                    <?php if(hasAccessAbility('edit_faq', $roles)): ?>
                                                      <a href="<?php echo e(route('admin.faq.edit',[$row->pk_no])); ?>" title="EDIT" class="btn btn-xs btn-outline-primary mr-1"><i class="la la-edit"></i></a>
                                                      <?php endif; ?>

                                                      <?php if(hasAccessAbility('delete_faq', $roles)): ?>
                                                      <a href="<?php echo e(route('admin.faq.delete',[$row->pk_no])); ?>" class="btn btn-xs btn-outline-danger mr-1" onclick="return confirm('Are you sure you want to delete the product with it\'s variant product ?')" title="DELETE"><i class="la la-trash"></i></a>
                                                      <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </section>
</div>


<?php $__env->stopSection(); ?>
<!--push from page-->
<?php $__env->startPush('custom_js'); ?>
<script src="<?php echo e(asset('app-assets/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/forms/select/form-select2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('app-assets/pages/customer.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>