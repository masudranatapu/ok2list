<?php $__env->startSection('content'); ?>

<!-- myads-page -->
<section id="main" class="clearfix myads-page">
	<div class="container"> 
		<div class="breadcrumb-section">
			<ol class="breadcrumb">
				<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
				<li>Create Shop</li>
			</ol>					
		</div>
		<div class="ads-info profile">
			<div class="row">
				<div class="col-md-4 text-center">
					<!-- header -->
					<?php echo $__env->make('users._user_dashboard_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- end header -->
				</div>
				<div class="col-md-8">
					<div class="my-ads section">
						<h3>Your Shop</h3>
						<hr>
						<div class="ad-item row mt-4 text-center">
							<div class="item-info col-12">

								<?php if( !empty( $data['shop_data'] ) ): ?> 
									<div class="ad-info" style="padding: 0px 25px;"> 
										<h3>Now you can visit your shop page or update !</h3> 
									</div>

									<a href="<?php echo e(route('shop_page_details',['id' => $data['shop_data']->pk_no, 'url_slug' => $data['shop_data']->url_slug ])); ?>" class="btn-primary btn">Let's go to your Shop</a> 
									<a href="<?php echo e(route('modify-shop')); ?>" class="btn-primary btn">Update Your Shop</a>
									
								<?php else: ?>

								<div class="ad-info" style="padding: 0px 25px;"> 
									<h3 class="item-price">You don't have any shop page yet !</h3>
									<p>Kindy hit the Create Your Shop button and create now. It's won't take more than 2 minutes !</p>
								</div>
								<a href="<?php echo e(route('create-shop')); ?>" class="btn-primary btn">Create Your Shop</a>

								<?php endif; ?>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_footer_script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/shop/index.blade.php ENDPATH**/ ?>