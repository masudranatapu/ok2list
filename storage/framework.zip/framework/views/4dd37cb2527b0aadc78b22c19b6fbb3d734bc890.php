<?php $__env->startSection('site-ads','active'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Dashboard</a>
</li>
<li class="breadcrumb-item active">Ads (Horizontal Banner Size: 1120*96px & Vartical Ads Size: 300*600px)
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
<section id="pagination">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-sm">
                <div class="card-header">
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">

                    <form action="<?php echo e(route('site.ads.update', $data->pk_no)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row d-flex justify-content-center">
                            <div class="col-md-9 col-lg-6">
                                <div class="form-group">
                                    <select name="position" class="form-control">
                                        <?php if(webAdList()): ?>
                                            <?php $__currentLoopData = webAdList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo e($data->name == $key ? 'selected' : ''); ?> ><?php echo e($val); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Status <span class="text-danger">*</span></label>
                                    <select name="status" class="form-control">
                                        <option value="1" <?php echo e($data->is_active == 1 ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e($data->is_active == 0 ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <hr>

                        <div class="row d-flex justify-content-center">
                            <div class="col-md-9 col-lg-6">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Photo Name</th>
                                            <th>Link</th>
                                            <th>File</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="input_fields_wrap">
                                        <?php if(isset($dataDetail) && count($dataDetail) > 0 ): ?>
                                        <?php $__currentLoopData = $dataDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="hidden" name="photo_id[]" class="form-control" value = "<?php echo e($row->pk_no  ?? ''); ?>" required>

                                                <input type="text" name="old_photo_name[]" class="form-control" value = "<?php echo e($row->name ?? ''); ?>" required placeholder="Photo name">
                                            </td>
                                            <td>

                                                <input type="text" name="old_link[]" class="form-control" value = "<?php echo e($row->link ?? ''); ?>" required placeholder="Photo link">
                                            </td>
                                            <td>
                                                <a href="<?php echo e(fileExit($row->photo)); ?>" target="_blank"><img src="<?php echo e(fileExit($row->photo)); ?>" width="150" /></a>
                                                <input type="file" name="old_photo[]" value ="" accept="image/*" class="form-control" >
                                            </td>
                                            <td>
                                                <?php if($key < 1): ?>
                                                <div class = "parent" style="margin-top: 8px;">
                                                    <a href="javascript:void(0)" class="btn-sm btn-primary add_field_button"><i class="la la-plus"></i></a>
                                                </div>
                                                <br>
                                                <?php endif; ?>
                                                <?php if($key > 0): ?>
                                                <div class = "parent" style="margin-top: 8px;">
                                                    <a href="<?php echo e(route('site.ads.deletephoto',$row->pk_no)); ?>" class="btn-sm btn-danger"><i class="la la-close"></i></a>
                                                </div>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <div class="pb-4 mt-3">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <a  href="<?php echo e(route('site.ads')); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
</div>

    <script type="text/javascript">
    $(document).ready(function() {
        var max_fields      = 10; //maximum input boxes allowed
        var wrapper         = $(".input_fields_wrap"); //Fields wrapper
        var add_button      = $(".add_field_button"); //Add button ID

        var x = 1; //initlal text box count
        $(add_button).click(function(e){ //on add input button click
            e.preventDefault();
            if(x < max_fields){ //max input box allowed
                x++; //text box increment
                $(wrapper).append('<tr class="customer_field"><td><input type="text" name="photo_name[]" class="form-control" required placeholder="Phone name"></td><td><input type="url" name="link[]" class="form-control" placeholder="Ads Link"> </td><td><input type="file" name="photo[]" class="form-control" required></td><td><div style="margin-top: 8px;"><a href="javascript:void(0)" class="btn-sm btn-danger remove_tr"><i class="la la-minus"></i></a></div></td></tr>'); //add input box
            }
        });


    });

    $(document).on('click', '.remove_tr', function(e){
        $(this).closest("tr").remove();
    })

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/admin/site-setting/web_ad_edit.blade.php ENDPATH**/ ?>