

<?php
$setting = setting();
?>

<footer id="footer" class="clearfix">
    <!-- footer-top -->
    <section class="footer-top clearfix">
        <div class="container">
            <div class="row">
                <!-- footer-widget -->
                <div class="col-md-3 col-6">
                    <div class="footer-widget">
                        <h3><?php echo app('translator')->get('web.quik_links'); ?></h3>
                        <ul>
                            <li><a href="<?php echo e(route('about-us')); ?>"><?php echo app('translator')->get('web.about_us'); ?></a></li>
                            <li><a href="<?php echo e(route('contact-us')); ?>"><?php echo app('translator')->get('web.contact_us'); ?></a></li>
                            <li><a href="<?php echo e(route('terms-conditions')); ?>"><?php echo app('translator')->get('web.t_conditions'); ?></a></li>
                            <li><a href="<?php echo e(route('privacy-policy')); ?>"><?php echo app('translator')->get('web.privacy_policy'); ?></a></li>
                            <li><a href="<?php echo e(route('site-map')); ?>"><?php echo app('translator')->get('web.sitemap'); ?></a></li>
                        </ul>
                    </div>
                </div><!-- footer-widget -->

                <!-- footer-widget -->
                <div class="col-md-3 col-6">
                    <div class="footer-widget">
                        <h3><?php echo app('translator')->get('web.how_to_sell_fast'); ?></h3>
                        <ul>
                            <li><a href="<?php echo e(route('how-to-sell-fast')); ?>"><?php echo app('translator')->get('web.how_to_sell_fast'); ?></a></li>
                            <li><a href="<?php echo e(route('get-membership')); ?>"><?php echo app('translator')->get('web.membership'); ?></a></li>
                            <li><a href="<?php echo e(route('promote-ads')); ?>"><?php echo app('translator')->get('web.promote_your_ad'); ?></a></li>
                            <li><a href="<?php echo e(route('promotions')); ?>"><?php echo app('translator')->get('web.promotions'); ?></a></li>
                            <li><a href="<?php echo e(route('faq')); ?>"><?php echo app('translator')->get('web.faq'); ?></a></li>
                        </ul>
                    </div>
                </div><!-- footer-widget -->

                <!-- footer-widget -->
                <div class="col-md-3 col-sm-6">

                    <div class="footer-widget social-widget">
                        <h3><?php echo app('translator')->get('web.follow_us_on'); ?></h3>
                        <ul>
                            <?php if($setting->facebook_link): ?>
                                <li><a target="_blank" href="<?php echo e($setting->facebook_link); ?>"><i class="fa fa-facebook-official"></i><?php echo app('translator')->get('web.Facebook'); ?></a></li>
                            <?php endif; ?>
                            <?php if($setting->twitter_link): ?>
                                <li><a target="_blank" href="<?php echo e($setting->twitter_link); ?>"><i class="fa fa-twitter-square"></i><?php echo app('translator')->get('web.Twitter'); ?></a></li>
                            <?php endif; ?>
                            <?php if($setting->instagram_link): ?>
                                <li><a target="_blank" href="<?php echo e($setting->instagram_link); ?>"><i class="fa fa-instagram"></i><?php echo app('translator')->get('web.Instagram'); ?></a></li>
                            <?php endif; ?>
                            <?php if($setting->linkedin_link): ?>
                                <li><a target="_blank" href="<?php echo e($setting->linkedin_link); ?>"><i class="fa fa-linkedin"></i><?php echo app('translator')->get('web.Linkedin'); ?></a></li>
                            <?php endif; ?>
                            <?php if($setting->whatsapp_link): ?>
                                <li><a target="_blank" href="<?php echo e($setting->whatsapp_link); ?>"><i class="fa fa-whatsapp"></i><?php echo app('translator')->get('web.Whatsapp'); ?></a></li>
                            <?php endif; ?>
                            <?php if($setting->youtube_link): ?>
                                <li><a target="_blank" href="<?php echo e($setting->youtube_link); ?>"><i class="fa fa-youtube-play"></i><?php echo app('translator')->get('web.Youtube'); ?></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="footer-widget news-letter">
                        <h3><?php echo app('translator')->get('web.newsletter'); ?></h3>
                        <p><?php echo app('translator')->get('web.newsletter_info'); ?></p>
                        <!-- form -->
                       <?php echo Form::open([ 'route' => 'subscribe', 'method' => 'post', 'class' => 'form-contact', 'files' => false , 'novalidate', 'autocomplete' => 'off']); ?>

                       <div class="form-group">
                            <div class="controls">
                               <?php echo Form::email('email', old('email'), ['class'=>'form-control', 'id' => 'email', 'placeholder' => 'email...', 'data-validation-required-message' => 'This field is required', 'tabindex' => 5]); ?>

                               <?php echo $errors->first('email', '<label class="help-block text-danger">:message</label>'); ?>

                             </div>
                        </div>
                            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('web.Subscribe_Now'); ?></button>
                       <?php echo Form::close(); ?><!-- form -->
                    </div>
                </div><!-- footer-widget -->
            </div><!-- row -->
        </div><!-- container -->
    </section><!-- footer-top -->
    <div class="footer-bottom clearfix text-center">
        <div class="container">
            <p><?php echo app('translator')->get('web.copyright'); ?> &copy; <?php echo app('translator')->get('web.gogoads_title'); ?> <?php echo e(date('Y')); ?></p>
            <!--
                ============Developer Md Rony (Contact: +88 01990572321)==========
             -->
        </div>
    </div><!-- footer-bottom -->
</footer><!-- footer -->

<?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/layouts/footer.blade.php ENDPATH**/ ?>