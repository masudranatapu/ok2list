<?php $__env->startSection('content'); ?>

	<section id="main" class="clearfix text-center">
		<div class="container">
			<div class="row">
				<div class="col-md-10 offset-md-1">
					<div class="found-section section">
						<h1>404</h1>
						<h2>Page Not Found</h2>
						<p>We can't seem to find the page you're looking for.</p>
						<a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Go to Home</a>
					</div>					
				</div>
			</div>
		</div><!-- container -->
	</section><!-- main -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom_footer_script'); ?>
   
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/error/404.blade.php ENDPATH**/ ?>