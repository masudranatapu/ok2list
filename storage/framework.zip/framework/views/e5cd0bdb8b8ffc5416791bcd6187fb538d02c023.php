<?php 
$jobInfo = $row->jobInfo ?? null ;
?>
<h4>Candidate preferences</h4>
    <div class="row form-group <?php echo $errors->has('mini_qualification') ? 'error' : ''; ?>">
        <label class="col-sm-3 label-title">Minimum qualification</label>
        <div class="col-sm-9">
            <div class="controls">
                <?php echo Form::select('mini_qualification', $mini_qualification_combo, $jobInfo->mini_qualification ?? old('mini_qualification'), ['class'=>'form-control select2', 'id' => 'mini_qualification','data-validation-required-message' => 'This field is required', 'placeholder' => 'Select one', 'tabindex' => 4, 'id' => 'mini_qualification']); ?>

                <?php echo $errors->first('mini_qualification', '<label class="help-block text-danger">:message</label>'); ?>

            </div>
        </div>
    </div>
    
    <div class="row form-group <?php echo $errors->has('req_expriance') ? 'error' : ''; ?>">
        <label class="col-sm-3 label-title">Required experience (years)</label>
        <div class="col-sm-9">
            <div class="controls">
                <?php echo Form::number('req_expriance', $jobInfo->req_expriance ?? old('req_expriance'), [ 'class' => 'form-control', 'maxlength' => '50', 'data-validation-maxlength-message' => 'Maxlength 50', 'placeholder' => 'Required experience (years)', 'tabindex' => 18]); ?>

                <?php echo $errors->first('req_expriance', '<label class="help-block text-danger">:message</label>'); ?>

            </div>
        </div>
    </div>
    <div class="row form-group <?php echo $errors->has('edu_specialization') ? 'error' : ''; ?>">
        <label class="col-sm-3 label-title">Educational specialization</label>
        <div class="col-sm-9">
            <div class="controls">
                <?php echo Form::select('edu_specialization', $edu_specialization_combo, $jobInfo->edu_specialization ?? old('edu_specialization') ?? 'dashboard', ['class'=>'form-control select2', 'id' => 'edu_specialization','data-validation-required-message' => 'This field is required', 'placeholder' => 'Select one', 'tabindex' => 4, 'id' => 'area_id']); ?>

                <?php echo $errors->first('edu_specialization', '<label class="help-block text-danger">:message</label>'); ?>

            </div>
        </div>
    </div>
    <div class="row form-group <?php echo $errors->has('skill') ? 'error' : ''; ?>">
        <label class="col-sm-3 label-title">Skills</label>
        <div class="col-sm-9">
            <div class="controls">
                <?php echo Form::text('skill', $jobInfo->skill ?? old('skill'), [ 'class' => 'form-control', 'maxlength' => '100', 'data-validation-maxlength-message' => 'Maxlength 100 characters', 'placeholder' => 'Skills', 'tabindex' => 18]); ?>

                <?php echo $errors->first('skill', '<label class="help-block text-danger">:message</label>'); ?>

            </div>
        </div>
    </div>
    <div class="row form-group <?php echo $errors->has('max_age') ? 'error' : ''; ?>">
        <label class="col-sm-3 label-title">Maximum age</label>
        <div class="col-sm-9">
            <div class="controls">
                <?php echo Form::number('max_age', $jobInfo->max_age ?? old('max_age'), [ 'class' => 'form-control', 'maxlength' => '60', 'data-validation-maxlength-message' => 'Maxlength 60', 'placeholder' => 'Maximum age', 'tabindex' => 18]); ?>

                <?php echo $errors->first('max_age', '<label class="help-block text-danger">:message</label>'); ?>

            </div>
        </div>
    </div>
    <div class="row form-group <?php echo $errors->has('pref_gender') ? 'error' : ''; ?>">
        <label class="col-sm-3 label-title">Gender preference</label>
        <div class="col-sm-9">
            <div class="controls">
                <?php echo Form::select('pref_gender', $gender_combo, $jobInfo->pref_gender ?? old('pref_gender'), ['class'=>'form-control select2', 'id' => 'pref_gender', 'placeholder' => 'Select gender', 'tabindex' => 4, 'id' => 'pref_gender']); ?>

                <?php echo $errors->first('pref_gender', '<label class="help-block text-danger">:message</label>'); ?>

            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\webdevs\gogoads\resources\views/ad_post/_candidate_preference_ad_jobpost.blade.php ENDPATH**/ ?>